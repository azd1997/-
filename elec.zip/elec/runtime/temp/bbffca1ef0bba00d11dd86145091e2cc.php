<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:65:"C:\wamp\www\elec\public/../application/admin\view\mode\mode1.html";i:1526027687;s:68:"C:\wamp\www\elec\public/../application/admin\view\public\header.html";i:1525751917;}*/ ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Elec-Monitor</title>
	<meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />

    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="__STATIC__/css/font.css">
	<link rel="stylesheet" href="__STATIC__/css/xadmin.css">
    
    <!--jquery库一定要放在最前面。需要注意的是引入本地js文件时，需重命名为xxxx.js形式，若存在xxx.xxxx.js之类的，无法解析路径-->
    
    <script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
    <script src="__STATIC__/lib/layui/layui.js" charset="utf-8"></script>
    
    
    <script type="text/javascript" src="__STATIC__/js/xadmin.js"></script>
	
    

</head>
  <body>
    <div class="x-nav">
      <span class="layui-breadcrumb">
        <a href="">首页</a>
        <a href="">用电监测</a>
        <a>
          <cite>用电模式</cite></a>
      </span>
      <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
      
    </div>
    
    <div class="x-body">
      

        
        <span class="x-right" style="line-height:40px">  >>共有数据：<?php echo $total['0']['id']; ?> 条</span>
        
  

      <table class="layui-table">
        <thead>
          <tr>
            <th>房间ID</th>
            <th>房间名称</th>
            <th>房间类型</th>
            <th>楼栋信息</th>
            <th>面积</th>
            <th>部门</th>
            <th>最新时间点</th>
            <th>电表读数</th>            
            <th>单位面积用电量</th>
            <th>模式分析</th>
          </tr>
        </thead>
        
        <tbody>
          <tr>
            <td><?php echo $mode10['id']; ?></td>
            <td><?php echo $mode10['name']; ?></td>
            <td><?php echo $mode10['type']; ?></td>
            <td><?php echo $mode10['bd_num']; ?></td>
            <td><?php echo $mode10['area']; ?></td>
            <td><?php echo $mode10['department_id']; ?></td>
            <td><?php echo $data16['0']['date']; ?> <?php echo $data16['0']['hour']; ?>h</td>
            <td><?php echo $data16['0']['1r']; ?></td>
            <td><?php echo $data16['0']['1a']; ?></td>
                                  
            <td class="td-manage">
              <a title="查看"  onclick="x_admin_show('编辑','<?php echo url('/admin/mode/mode/roomid/1'); ?>')" href="javascript:;">
                <i class="layui-icon">&#xe63c;</i>
              </a>              
            </td>
          </tr>
          
          <tr>
            <td><?php echo $mode11['id']; ?></td>
            <td><?php echo $mode11['name']; ?></td>
            <td><?php echo $mode11['type']; ?></td>
            <td><?php echo $mode11['bd_num']; ?></td>
            <td><?php echo $mode11['area']; ?></td>
            <td><?php echo $mode11['department_id']; ?></td>
            <td><?php echo $data16['0']['date']; ?> <?php echo $data16['0']['hour']; ?>h</td>
            <td><?php echo $data16['0']['2r']; ?></td>
            <td><?php echo $data16['0']['2a']; ?></td>
                                  
            <td class="td-manage">
              <a title="查看"  onclick="x_admin_show('编辑','<?php echo url('/admin/mode/mode/roomid/2'); ?>')" href="javascript:;">
                <i class="layui-icon">&#xe63c;</i>
              </a>              
            </td>
          </tr>
          
          <tr>
            <td><?php echo $mode12['id']; ?></td>
            <td><?php echo $mode12['name']; ?></td>
            <td><?php echo $mode12['type']; ?></td>
            <td><?php echo $mode12['bd_num']; ?></td>
            <td><?php echo $mode12['area']; ?></td>
            <td><?php echo $mode12['department_id']; ?></td>
            <td><?php echo $data16['0']['date']; ?> <?php echo $data16['0']['hour']; ?>h</td>
            <td><?php echo $data16['0']['3r']; ?></td>
            <td><?php echo $data16['0']['3a']; ?></td>
                                  
            <td class="td-manage">
              <a title="查看"  onclick="x_admin_show('编辑','<?php echo url('/admin/mode/mode/roomid/3'); ?>')" href="javascript:;">
                <i class="layui-icon">&#xe63c;</i>
              </a>              
            </td>
          </tr>
          
          <tr>
            <td><?php echo $mode13['id']; ?></td>
            <td><?php echo $mode13['name']; ?></td>
            <td><?php echo $mode13['type']; ?></td>
            <td><?php echo $mode13['bd_num']; ?></td>
            <td><?php echo $mode13['area']; ?></td>
            <td><?php echo $mode13['department_id']; ?></td>
            <td><?php echo $data16['0']['date']; ?> <?php echo $data16['0']['hour']; ?>h</td>
            <td><?php echo $data16['0']['4r']; ?></td>
            <td><?php echo $data16['0']['4a']; ?></td>
                                  
            <td class="td-manage">
              <a title="查看"  onclick="x_admin_show('编辑','<?php echo url('/admin/mode/mode/roomid/4'); ?>')" href="javascript:;">
                <i class="layui-icon">&#xe63c;</i>
              </a>              
            </td>
          </tr>
          
          <tr>
            <td><?php echo $mode14['id']; ?></td>
            <td><?php echo $mode14['name']; ?></td>
            <td><?php echo $mode14['type']; ?></td>
            <td><?php echo $mode14['bd_num']; ?></td>
            <td><?php echo $mode14['area']; ?></td>
            <td><?php echo $mode14['department_id']; ?></td>
            <td><?php echo $data16['0']['date']; ?> <?php echo $data16['0']['hour']; ?>h</td>
            <td><?php echo $data16['0']['5r']; ?></td>
            <td><?php echo $data16['0']['5a']; ?></td>
                                  
            <td class="td-manage">
              <a title="查看"  onclick="x_admin_show('编辑','<?php echo url('/admin/mode/mode/roomid/5'); ?>')" href="javascript:;">
                <i class="layui-icon">&#xe63c;</i>
              </a>              
            </td>
          </tr>
          
          <tr>
            <td><?php echo $mode15['id']; ?></td>
            <td><?php echo $mode15['name']; ?></td>
            <td><?php echo $mode15['type']; ?></td>
            <td><?php echo $mode15['bd_num']; ?></td>
            <td><?php echo $mode15['area']; ?></td>
            <td><?php echo $mode15['department_id']; ?></td>
            <td><?php echo $data16['0']['date']; ?> <?php echo $data16['0']['hour']; ?>h</td>
            <td><?php echo $data16['0']['6r']; ?></td>
            <td><?php echo $data16['0']['6a']; ?></td>
                                  
            <td class="td-manage">
              <a title="查看"  onclick="x_admin_show('编辑','<?php echo url('/admin/mode/mode/roomid/6'); ?>')" href="javascript:;">
                <i class="layui-icon">&#xe63c;</i>
              </a>              
            </td>
          </tr>
          
          <tr>
            <td><?php echo $mode16['id']; ?></td>
            <td><?php echo $mode16['name']; ?></td>
            <td><?php echo $mode16['type']; ?></td>
            <td><?php echo $mode16['bd_num']; ?></td>
            <td><?php echo $mode16['area']; ?></td>
            <td><?php echo $mode16['department_id']; ?></td>
            <td><?php echo $data16['0']['date']; ?> <?php echo $data16['0']['hour']; ?>h</td>
            <td><?php echo $data16['0']['7r']; ?></td>
            <td><?php echo $data16['0']['7a']; ?></td>
                                  
            <td class="td-manage">
              <a title="查看"  onclick="x_admin_show('编辑','<?php echo url('/admin/mode/mode/roomid/7'); ?>')" href="javascript:;">
                <i class="layui-icon">&#xe63c;</i>
              </a>              
            </td>
          </tr>
          
          <tr>
            <td><?php echo $mode17['id']; ?></td>
            <td><?php echo $mode17['name']; ?></td>
            <td><?php echo $mode17['type']; ?></td>
            <td><?php echo $mode17['bd_num']; ?></td>
            <td><?php echo $mode17['area']; ?></td>
            <td><?php echo $mode17['department_id']; ?></td>
            <td><?php echo $data16['0']['date']; ?> <?php echo $data16['0']['hour']; ?>h</td>
            <td><?php echo $data16['0']['8r']; ?></td>
            <td><?php echo $data16['0']['8a']; ?></td>
                                  
            <td class="td-manage">
              <a title="查看"  onclick="x_admin_show('编辑','<?php echo url('/admin/mode/mode/roomid/8'); ?>')" href="javascript:;">
                <i class="layui-icon">&#xe63c;</i>
              </a>              
            </td>
          </tr>
          
          <tr>
            <td><?php echo $mode18['id']; ?></td>
            <td><?php echo $mode18['name']; ?></td>
            <td><?php echo $mode18['type']; ?></td>
            <td><?php echo $mode18['bd_num']; ?></td>
            <td><?php echo $mode18['area']; ?></td>
            <td><?php echo $mode18['department_id']; ?></td>
            <td><?php echo $data16['0']['date']; ?> <?php echo $data16['0']['hour']; ?>h</td>
            <td><?php echo $data16['0']['9r']; ?></td>
            <td><?php echo $data16['0']['9a']; ?></td>
                                  
            <td class="td-manage">
              <a title="查看"  onclick="x_admin_show('编辑','<?php echo url('/admin/mode/mode/roomid/9'); ?>')" href="javascript:;">
                <i class="layui-icon">&#xe63c;</i>
              </a>              
            </td>
          </tr>
          
          <tr>
            <td><?php echo $mode19['id']; ?></td>
            <td><?php echo $mode19['name']; ?></td>
            <td><?php echo $mode19['type']; ?></td>
            <td><?php echo $mode19['bd_num']; ?></td>
            <td><?php echo $mode19['area']; ?></td>
            <td><?php echo $mode19['department_id']; ?></td>
            <td><?php echo $data16['0']['date']; ?> <?php echo $data16['0']['hour']; ?>h</td>
            <td><?php echo $data16['0']['10r']; ?></td>
            <td><?php echo $data16['0']['10a']; ?></td>
                                  
            <td class="td-manage">
              <a title="查看"  onclick="x_admin_show('编辑','<?php echo url('/admin/mode/mode/roomid/10'); ?>')" href="javascript:;">
                <i class="layui-icon">&#xe63c;</i>
              </a>              
            </td>
          </tr>
          
          
          
        </tbody>
      </table>
      <div class="page">
        <div>
                   
          <span class="current">1</span>
          <a class="num" href="mode2">2</a>
          <a class="num" href="mode3">3</a>
          <a class="num" href="mode4">4</a>
          <a class="num" href="mode5">5</a>
          <a class="num" href="mode6">6</a>
          <a class="num" href="mode7">7</a>
          <a class="num" href="mode8">8</a>
          <a class="num" href="mode9">9</a>
          
        </div>
      </div>
      <br />
      <blockquote class="layui-elem-quote layui-quote-nm">房间面积单位为m^2，电量单位为kW·h;<br />各房间隶属的部门信息未作定义；<br />前70个房间静态展示数据库中最近时间点数据；71~79号房间动态展示所有数据；80~81号房间为实际电表采集数据展示；82号用以展示单个房间全时间段用电数据</blockquote>
      
   
			
    </div>
    
  
    <script>
      layui.use(['form','layer','laydate','laypage'], function(){
        
        var form = layui.form;
      var layer = layui.layer;
      var laydate = layui.laydate;
      var laypage= layui.laypage;
        
        //执行一个laydate实例
        laydate.render({
          elem: '#start' ,//指定元素
          type: 'datetime'
        });

        //执行一个laydate实例
        laydate.render({
          elem: '#end', //指定元素
          type: 'datetime'
        });
        
        //完整功能
			  laypage.render({
			    elem: 'page'
			    ,count: 9
			    ,layout: ['count', 'prev', 'page', 'next', 'limit', 'skip']
			    ,jump: function(obj){
			      console.log(obj)
			    }
			  });
      });
			
//			var ok1=false;
//			var ok2=false;
//			var ok3=false;
//			//验证规则
//			form.verify({
//				//三个input必须非空，点击按钮才能跳转到新画面，否则报错。这个功能是由required属性实现的。
//				//这里用于对其作自定义的验证
//				start_time:function(value){
//					if(!isNaN(value)){
//						ok1=true;
//					}
//				},
//				end_time:function(value){
//					if(!isNaN(value)){
//						ok2=true;
//					}
//				},
//				bianhao: function(value){
//					if(!isNaN(value)){
//						ok3=true;
//					}
//				}
//			});
       /*用户-停用*/
      function member_stop(obj,id){
          layer.confirm('确认要停用吗？',function(index){

              if($(obj).attr('title')=='启用'){

                //发异步把用户状态进行更改
                $(obj).attr('title','停用')
                $(obj).find('i').html('&#xe62f;');

                $(obj).parents("tr").find(".td-status").find('span').addClass('layui-btn-disabled').html('已停用');
                layer.msg('已停用!',{icon: 5,time:1000});

              }else{
                $(obj).attr('title','启用')
                $(obj).find('i').html('&#xe601;');

                $(obj).parents("tr").find(".td-status").find('span').removeClass('layui-btn-disabled').html('已启用');
                layer.msg('已启用!',{icon: 5,time:1000});
              }
              
          });
      }

      /*用户-删除*/
      function member_del(obj,id){
          layer.confirm('确认要删除吗？',function(index){
              //发异步删除数据
              $(obj).parents("tr").remove();
              layer.msg('已删除!',{icon:1,time:1000});
          });
      }



      function delAll (argument) {

        var data = tableCheck.getData();
  
        layer.confirm('确认要删除吗？'+data,function(index){
            //捉到所有被选中的，发异步进行删除
            layer.msg('删除成功', {icon: 1});
            $(".layui-form-checked").not('.header').parents('tr').remove();
        });
      }
    </script>
 
    <script>
    	//异步提交精确查询条件
    	$(function(){
    		$("#searchbtn").on('click',function(){
							var x = document.getElementById('start');
							var y = document.getElementById('end');
							var z= document.getElementById('bianhao');
							var data = $("#searchform").serializeArray();
							
    		//	if(ok1&ok2&ok3){
    					$.ajax({
		    				type: 'post',
		    				
		    				url: "<?php echo url('sites/search'); ?>",
		    				data: data,
		    				//datatype: "json",	    				
		    				error:function(){
		    					alert(x.value+' '+y.value+' '+z.value);
		    					alert(data);
		    					
		    				},
		    				//timeout:1000,
		    				success: function(data){
		    					console.log(data);
//		    					if(data.status==1){
//		    						alert(data.message);   						
//		    						window.location.href ="<?php echo url('sites/searched'); ?>";
//		    					}else{
//		    						alert(data.message); 						
//		    						window.location.href ="<?php echo url('sites/index'); ?>";
//		    					}
		    				}
		    				//ceshi: alert("ceshi")
		    			})
    		
    		})
    	})
    	
    </script>
    
  </body>

</html>

