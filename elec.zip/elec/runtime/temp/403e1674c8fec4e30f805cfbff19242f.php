<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:65:"C:\wamp\www\elec\public/../application/home\view\index\index.html";i:1523376950;}*/ ?>
<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Log in Elec-Monitor</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="__STATIC__/framework/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="__STATIC__/assets/fonts/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="__STATIC__/css/form-elements.css">
        <link rel="stylesheet" href="__STATIC__/css/style.css">
		<link href="//netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="__STATIC__/assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="__STATIC__/assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="__STATIC__/assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="__STATIC__/assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="__STATIC__/assets/ico/apple-touch-icon-57-precomposed.png">
		
		<style>
			.form-footer {
				height=30px;
				padding: 0px 25px 10px 0px;
				background: #eee;
				-moz-border-radius: 0 0 4px 4px; -webkit-border-radius: 0 0 4px 4px; border-radius: 0 0 4px 4px;
				text-align: right;
			} 
			
			/*.my-form-align{
				text-align: center;
				float:right;*/
				
			}
		
		</style>

    </head>

    <body>

        <!-- Top content -->
        <div class="top-content">
        	
            <div class="inner-bg" >
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2 text">
                            <h1><strong>Elec-Monitor</strong></h1>
                            <div class="description">
                            	<p>
	                            	We are committed to monitoring urban energy consumption, and we try our best to make the future better!
	                            
                            	</p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 form-box ">
                        	<div class="form-top">
                        		<div class="form-top-left">
                        			<h3>Login to our site</h3>
                            		<p>Enter your username and password:</p>
                        		</div>
                        		<div class="form-top-right">
                        			<i class="fa fa-key"></i>
                        		</div>
                            </div>
                            <div class="form-bottom">
			                    <form role="form" action="" method="post" class="login-form">
			                    	<div class="form-group">
			                    		<label class="sr-only" for="form-username">Username</label>
			                        	<input type="text" name="form-username" placeholder="Username..." class="form-username form-control" id="form-username">
			                        </div>
			                        <div class="form-group">
			                        	<label class="sr-only" for="form-password">Password</label>
			                        	<input type="password" name="form-password" placeholder="Password..." class="form-password form-control" id="form-password">
			                        </div>
			                        <button type="submit" class="btn">Sign in!</button>
			                    </form>
		                    </div>
							<div class="form-footer">
							<p class="small">No accounts？<a href="templates/signup.html">Sign up now！</a></p>
							</div>
                        </div>
                    </div>
					<!--
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 social-login">
                        	<h3>...or login with:</h3>
                        	<div class="social-login-buttons">
	                        	<a class="btn btn-link-1 btn-link-1-facebook" href="#">
	                        		<i class="fa fa-facebook"></i> Facebook
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-twitter" href="#">
	                        		<i class="fa fa-twitter"></i> Twitter
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-google-plus" href="#">
	                        		<i class="fa fa-google-plus"></i> Google Plus
	                        	</a>
                        	</div>
                        </div>
                    </div>
					-->
                </div>
            </div>
            
        </div>


        <!-- Javascript -->
        <script src="__STATIC__/js/jquery-1.11.1.min.js"></script>
        <script src="__STATIC__/framework/bootstrap/js/bootstrap.min.js"></script>
        <script src="__STATIC__/js/jquery.backstretch.min.js"></script>
        
        <script>
        	 jQuery(document).ready(function() {
	
			    /*
			        Fullscreen background
			    */
			    $.backstretch("__STATIC__/assets/img/backgrounds/1.jpg");
			    
			    /*
			        Form validation
			    */
			    $('.login-form input[type="text"], .login-form input[type="password"], .login-form textarea').on('focus', function() {
			    	$(this).removeClass('input-error');
			    });
			    
			    $('.login-form').on('submit', function(e) {
			    	
			    	$(this).find('input[type="text"], input[type="password"], textarea').each(function(){
			    		if( $(this).val() == "" ) {
			    			e.preventDefault();
			    			$(this).addClass('input-error');
			    		}
			    		else {
			    			$(this).removeClass('input-error');
			    		}
			    	});
			    	
			    });
			    
			    
			});

        </script>
        
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

    </body>

</html>