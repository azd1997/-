<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:66:"C:\wamp\www\elec\public/../application/admin\view\sites\site2.html";i:1523363897;s:75:"C:\wamp\www\elec\public/../application/admin\view\public\echart_header.html";i:1523284191;}*/ ?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Elec-Monitor</title>
        <meta name="renderer" content="webkit|ie-comp|ie-stand">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8" />
        <meta http-equiv="Cache-Control" content="no-siteapp" />

        <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
	    <link rel="stylesheet" href="__STATIC__/css/font.css">
		<link rel="stylesheet" href="__STATIC__/css/xadmin.css">
        
        <script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
        
        <script src="__STATIC__/js/echarts.js" charset="utf-8"></script>
        <script src="//cdn.bootcss.com/echarts/3.3.2/extension/bmap.min.js" type="text/javascript"></script>
        <script src="http://echarts.baidu.com/asset/map/js/china.js"></script>
        
        <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/echarts.min.js"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts-gl/echarts-gl.min.js"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts-stat/ecStat.min.js"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/extension/dataTool.min.js"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/map/js/china.js"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/map/js/world.js"></script>
       <script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=ZUONbpqGBsYGXNIYHicvbAbM"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/extension/bmap.min.js"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/simplex.js"></script>
        
        
        
        
    </head>
    <body>
        <div class="x-body">
            
            <!-- 为 ECharts 准备一个具备大小（宽高）的 DOM -->
            <div id="main" style="width: 100%;height:450px;"></div>
            
        </div>
        
        
        
        
        
        <script type="text/javascript">
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('main'));
		var app = {};
		option = null;//初始化
		
		//echarts中的函数，展示一个加载的图标
		myChart.showLoading();
		
		$.ajax({
    				type: 'GET',
    				url: "<?php echo url('sites/site2_json'); ?>",
    				datatype: "json",
    				timeout: 1000,
    				error: function(){
    					alert("数据加载出错，请稍后再试~");
    				},
    				success: function(site2_data){
    					
    					//alert("加载成功");
    					//隐藏加载图标
						myChart.hideLoading();
						
						
						
						option = {
							
							title: {
                				text: '<?php echo $site2['elec_loca']; ?>  用电数据',
                				x: 'center',
                				y: 'top',
            				},
							
							tooltip:{
								trigger: 'axis',
								axisPointer: {
									type:'shadow',
									label: {
										show:true
									}
								}			
							},
							
							toolbox: {
								show: true,
								feature: {
									mark: {show:true},									
									dataView: {show:true, readOnly:false},
									dataZoom:{show:true},
									magicType: {show:true,type:['line','bar']},
									restore: {show:true},
									saveAsImage: {show:true}
								}
							},
							//calculable用于拖拽重计算，在这张图里必须是true
							calculable: true,
							
							legend: {
								data:['电表实时读数','每小时用电量'],
								itemGap: 5,
								y: 30,//单位是px，起点是容器顶端
							},
							
							grid: {
								top: '20%',
								left: '5%',
								right: '5%',
								containLabel: true
							},
							
							xAxis: [
								{
									type: 'category',//因为已经把时间转为字符串了，这里就采用category而不是time
									data: site2_data.date_time
								}
							],
							
							yAxis: [
								{
									type: 'value',
									name: '电表实时读数 kW·h',
									position: 'left',
									scale: true
			//						
								},
								{
									type: 'value',
									name: '每小时用电量 kW·h',
									position: 'right',
									scale: true  //设置y轴起点终点自适应
								}
							],
							
							dataZoom: [
								{
									show: true,
									start:94,
									end:100
								},//水平条
								{   //好像没起作用
									type: 'inside',
									start:94,
									end:100
								},
								{   //竖直条
									show: true,
									yAxisIndex: 0,
									filterMode: 'empty',
									width: 30,
									height: '63%',
									showDataShadow: false,
									left: '0%'
								},
								{   //竖直条
									show: true,
									yAxisIndex: 1,
									filterMode: 'empty',
									width: 30,
									height: '63%',
									showDataShadow: false,
									left: '97%'
								}
							],
							
							series: [
								{
									name: '电表实时读数',
									type: 'line',
									yAxisIndex:0,
									data: site2_data.realtime_elec
								},
								{
									name: '每小时用电量',
									type: 'line',
									yAxisIndex:1,
									data: site2_data.delta_elec
								}
							]
						};
						
						myChart.setOption(option);
    				}
		
		
		
			
			
			
		});
		

    </script>
   
    </body>
</html>