<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:64:"C:\wamp\www\elec\public/../application/admin\view\mode\mode.html";i:1527004703;s:75:"C:\wamp\www\elec\public/../application/admin\view\public\echart_header.html";i:1523284191;}*/ ?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Elec-Monitor</title>
        <meta name="renderer" content="webkit|ie-comp|ie-stand">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8" />
        <meta http-equiv="Cache-Control" content="no-siteapp" />

        <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
	    <link rel="stylesheet" href="__STATIC__/css/font.css">
		<link rel="stylesheet" href="__STATIC__/css/xadmin.css">
        
        <script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
        
        <script src="__STATIC__/js/echarts.js" charset="utf-8"></script>
        <script src="//cdn.bootcss.com/echarts/3.3.2/extension/bmap.min.js" type="text/javascript"></script>
        <script src="http://echarts.baidu.com/asset/map/js/china.js"></script>
        
        <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/echarts.min.js"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts-gl/echarts-gl.min.js"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts-stat/ecStat.min.js"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/extension/dataTool.min.js"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/map/js/china.js"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/map/js/world.js"></script>
       <script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=ZUONbpqGBsYGXNIYHicvbAbM"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/extension/bmap.min.js"></script>
       <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/simplex.js"></script>
        
        
        
        
    </head>
    <body>
        <div class="x-body">
        	
	        <div class="layui-row">
		        <form id="searchform" moethod="post" class="layui-form layui-col-md12 x-so">       	
		        	<button class="layui-btn layui-btn-warm" lay-filter="search" disabled="disabled">根据日期查询</button>       	
		          	<input class="layui-input" type="text" placeholder="输入房间id" name="roomid" id="roomid" lay-verify="required" >
		          
		          	<input class="layui-input" type="text" placeholder="选择日期" name="start" id="start" lay-verify="required">
		          	<button class="layui-btn"  lay-submit type="submit" lay-filter="*" id="searchbtn"><i class="layui-icon">&#xe615;</i></button>        	
		        </form>
	      	</div>
            
            <!-- 为 ECharts 准备一个具备大小（宽高）的 DOM -->
            <div id="main" style="width: 100%;height:450px;"></div>
            

			
			<table class="layui-table">
		        <thead>
		          <tr>
		            
		            <th>房间名称</th>
		            <th>房间类型</th>
		            
		            <th>日期</th>
		            <th>日用电量</th>            
		            <th>用电模式</th>
		            <th>用电水平</th>
		          </tr>
		        </thead>
		        
		        <tbody>
		          <tr>
		            <td><?php echo $room_name_str; ?></td>
		            <td><?php echo $room_type_str; ?></td>
		            <td><?php echo $date_show_str; ?></td>
		            <td><?php echo $day_elec; ?> kW·h</td>
		            <td><?php echo $modedata4; ?></td>
		            <td><?php echo $level_level; ?></td>
		            
		          </tr>
		         </tbody>
		        </table>
          
			
            
        </div>
 
 		<script src="__STATIC__/lib/layui/layui.js"></script>
 		
        <script type="text/javascript">
        	var mydate;
        	
        	layui.use(['jquery','layer','form','laydate'], function(){
				var $ = layui.$
				,layer = layui.layer
				,form = layui.form
				,laydate = layui.laydate;
			  	
			  	
			  	
				//执行一个laydate实例
				laydate.render({
				   elem: '#start' //指定元素
				   ,min: '2016-1-1'
				   ,max: '2016-12-31'
				   ,
//				   done: function(value,date){
//					    console.log(value); //得到日期生成的值，如：2017-08-18					    
//						layer.alert('你选择的日期是：' + value + '<br><br>获得的对象是' + JSON.stringify(date));
//						mydate=JSON.stringify(date);
						
//						var url = '/admin.php/mode/search?date='+value
//						window.location.href = url;
						
						
//						$.ajax({
//	    				type: 'post',
//	    				url: "<?php echo url('mode/search'); ?>",
//	    				data: "data="+value,
//	    				datatype: "json",
//	    				error:function(){
//	    					alert('3333');
//	    					return false;
//	    				},
//	    				success: function(data){
//	    					//if(data.status==1){
//	    						//alert(data.message);
//	    						alert('2222');
//	    						alert(mydate);
//	    						window.location.href ="<?php echo url('mode/search'); ?>";
//	    					
//	    				}
//	    				
//	    				})
//				   }
				  
				});
				//console.log(mydate);
				form.on('submit(*)', function(data){
					console.log(data.elem) //被执行事件的元素DOM对象，一般为button对象
					console.log(data.form) //被执行提交的form对象，一般在存在form标签时才会返回
					console.log(data.field) //当前容器的全部表单字段，名值对形式：{name: value}
					
					var date_value = data.field.start;
					var roomid = data.field.roomid;
					
					var url = '/admin.php/mode/search?date='+date_value+'&roomid='+roomid;
					window.location.href = url;
//					$.ajax({
//		    				type: 'post',
//		    				
//		    				url: "<?php echo url('mode/search'); ?>",
//		    				data: JSON.stringify(data.field),
//		    				datatype: "json",	    				
////		    				error:function(){
////		    					
////		    					alert('333333');
////		    					alert(mydate);
////		    					
////		    				},
//		    				//timeout:1000,
//		    				success: function(data){
//		    					console.log(data);
//		    					alert('222222');    			  						
//		    					window.location.href ="<?php echo url('mode/search'); ?>";
//		    				}
//		    				//ceshi: alert("ceshi")
//		    		})
					
					return false; //阻止表单跳转。如果需要表单跳转，去掉这段即可。
				});
			});
        </script>
        
        <script>
//	    	$(function(){
//	    		$("#searchbtn").on('click',function(){
//	    			//alert("测试")
//	    			$.ajax({
//	    				type: 'post',
//	    				url: "<?php echo url('mode/search'); ?>",
//	    				data: $(".layui-form").serialize(),
//	    				datatype: "json",
//	    				error:function(){
//	    					alert('3333');
//	    					return false;
//	    				},
//	    				success: function(data){
//	    					//if(data.status==1){
//	    						//alert(data.message);
//	    						alert('2222');
//	    						alert($(".layui-form").serialize());
//	    						window.location.href ="<?php echo url('mode/search'); ?>";
//	    					
//	    				}
//	    				//ceshi: alert("ceshi")
//	    			})
//	    		})
//	    	})
	    </script>
        
        <script type="text/javascript">
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('main'));
		var app = {};
		option = null;//初始化
		
		
		
		
		//echarts中的函数，可能是为图标加载做准备，不太清楚
		myChart.showLoading();
		
		$.ajax({
    				type: 'GET',
    				url: "<?php echo url('mode/modedata'); ?>",
    				
    				datatype: "json",
    				timeout: 1000,
    				error: function(){
    					alert("数据加载出错，请稍后再试~");
    				},
    				success: function(result){
    					

						myChart.hideLoading();
						
		
						option = {
							
							title: {
                				text: result.name+' 日单位面积用电数据',
                				x: 'center',
                				y: 'top',
            				},
							
							tooltip:{
								trigger: 'axis',
								axisPointer: {
									type:'shadow',
									label: {
										show:true
									}
								}			
							},
							
							toolbox: {
								show: true,
								feature: {
									mark: {show:true},									
									dataView: {show:true, readOnly:false},
									dataZoom:{show:true},
									magicType: {show:true,type:['line','bar']},
									restore: {show:true},
									saveAsImage: {show:true}
								}
							},
							//calculable用于拖拽重计算，在这张图里必须是true
							calculable: true,
							
							legend: {
								data:['单位面积每小时用电量'],
								itemGap: 5,
								y: 30,//单位是px，起点是容器顶端
							},
							
							grid: {
								top: '20%',
								left: '5%',
								right: '5%',
								containLabel: true
							},
							
							xAxis: [
								{
									type: 'category',//因为已经把时间转为字符串了，这里就采用category而不是time
									data: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]
								}
							],
							
							yAxis: [
								{
									type: 'value',
									name: '        单位面积每小时用电量 kW·h',
									position: 'left',
									//scale: true
								},

							],
							
						
							
							
							series: [
								
								{
									name: '单位面积每小时用电量',
									type: 'line',
									data: result.data
								}
							]
						};
						
						myChart.setOption(option);
    				}
		
		
		//
		//$.get('site3.json', function(site3_data){
			
			
			
			
		});
		

    </script>
   
    </body>
</html>