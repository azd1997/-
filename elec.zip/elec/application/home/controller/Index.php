<?php
namespace app\home\controller;

use app\home\common\Base;

class Index extends Base
{
    public function index()
    {
        return $this->view->fetch('index');
    }
}
