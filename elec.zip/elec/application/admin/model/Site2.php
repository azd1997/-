<?php

namespace app\admin\model;

use think\Model;

class Site2 extends Model
{
    protected $table = 'e02';
}
