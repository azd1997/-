<?php

namespace app\admin\model;

use think\Model;
use think\Db;

class Room_info extends Model
{
    protected $table = 'room_info';
    
    
    //将房间类型编号转为类型解释
    public function getTypeAttr($val){
    	
    	$type = Db::table('room_type') -> where('id',$val) -> value('room_type');
    	return $type;
    }
    
    //将楼栋编号查询为楼栋信息
    public function getBdNumAttr($val){
    	
    	$type = Db::table('room_building') -> where('id',$val) -> value('building');
    	return $type;
    }
}
