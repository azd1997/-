<?php

namespace app\admin\model;

use think\Model;

class Site3 extends Model
{
    protected $table = '24h_elec';
}
