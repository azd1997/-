<?php

namespace app\admin\model;

use think\Model;
use think\Db;

class Room_mode extends Model
{
    protected $table = 'roommode_all';
    
    
}
