<?php

namespace app\admin\model;

use think\Model;

class Room_level extends Model
{
    //
}
