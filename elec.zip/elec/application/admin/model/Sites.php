<?php

namespace app\admin\model;

use think\Model;

class Sites extends Model
{
    protected $table = 'elec_loca';
    
    //创建获取器方法，用来实现时间戳到年月日的转换。要注意这个获取器的命名规则，请查阅手册相关内容
    public function getAddTimeAttr($val){
    	return date('Y/m/d',$val);
    }
}
