<?php

namespace app\admin\model;

use think\Model;

class Mode extends Model
{
    protected $table = 'room_mode';
}
