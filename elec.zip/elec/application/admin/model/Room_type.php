<?php

namespace app\admin\model;

use think\Model;

class Room_type extends Model
{
    protected $table = 'room_type';
}
