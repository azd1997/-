<?php

namespace app\admin\model;

use think\Model;

class Site1 extends Model
{
    protected $table = 'e01';
}
