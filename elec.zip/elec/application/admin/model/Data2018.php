<?php

namespace app\admin\model;

use think\Model;

class Data2018 extends Model
{
    protected $table = 'room_data2018';
}
