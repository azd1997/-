<?php

namespace app\admin\controller;

use app\admin\common\Base;
use think\Request;
use app\admin\model\Admin as AdminModel;
//管理员的模型名是Admin，当前的控制器名是Administrator，
//如果说控制器名也为Admin,那么会产生冲突，一定要使用别名解决，如上使用别名AdminModel
//当然，现在是不冲突的,也没必要使用别名


class Administrator extends Base
{
    //显示管理员首页
    
    
    public function index()
    {
    	//1、读取Admin管理员表的信息
    	$admin =AdminModel::get(['administrator' => 'eiger']);//从administrator字段中获取'eiger'这一用户所在行
    	
    	//2、将当前管理员的信息赋值给模板
    	$this -> view -> assign('admin', $admin);  //将admin变量（对象）赋值给admin模板,这里的admin模板是渲染输出数据所用，其命名须与变量名保持一致
    	
        //渲染输出模板"admin-list"
        return $this->view->fetch('admin-list');
    }
    
    public function admin_add()
    {
        return $this->view->fetch('admin-add');
    }
    public function admin_cate()
    {
        return $this->view->fetch('admin-cate');
    }
    
    public function admin_edit(Request $request)
    {
    	$admin=AdminModel::get($request -> param('id'));
    	$this ->view->assign('admin',$admin);
        return $this->view->fetch('admin-edit');
    }
    
    public function admin_role()
    {
        return $this->view->fetch('admin-role');
    }
    public function admin_rule()
    {
        return $this->view->fetch('admin-rule');
    }
    public function admin_role_add()
    {
        return $this->view->fetch('role-add');
    }


	/**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update(Request $request)
    {
    	
//  	
//  	$message = '更新成功！';
		if($request -> isAjax(true)){
			
			
//  		//获取提交的数据，自动过滤空值
			$data =array_filter($request -> param());
	//  		//设置更新条件
			$administrator = $data['administrator'];
			$map=['administrator'=>$administrator];
			//$map = ['is_update' => $data['is_update']];
	//  		//更新用户表（静态方法）
			$res =AdminModel::update($data,$map);
		
		//更新成功的提示信息
			$status = 1;
  			$message="更新测试";
//  		
//  		//如果更新失败
//  		if(is_null($res)){
//  			$status=0;
//  			$message='更新失败！';
//  		}
//  		
		}else{
			$status=0;
			$message="提交异常";
		}
//      return ['status'=>$status, 'message'=>$message];
    	return ['status'=>$status, 'message'=>$message];
    }







    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request  $request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * 显示指定的资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    
    /**
     * 删除指定资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function delete($id)
    {
        //
    }
}
