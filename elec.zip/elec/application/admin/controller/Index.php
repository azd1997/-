<?php
namespace app\admin\controller;

use app\admin\common\Base;
use think\Controller;


class Index extends Base
{
    public function index()
    {
        $this -> isLogin();
        return $this->view->fetch('index');//index对应着admin/view/index/里的index.html
    }
    
    public function welcome()
    {
    	$now_unix = time();
    	$now=date('Y/m/d H:m:s', $now_unix);
    	$this -> view -> assign('now', $now);
        return $this->view->fetch('welcome');
    }
    
    public function jump()
    {
    	
        //$this->success('页面跳转成功~','home/index/index');
        //return $this->redirect("__ROOT__/home.php/index/index");
		//$this->fetch("home@index/index"); 
		//return file_get_contents(url("home/index/index","",true,true));   
		//在实现页面跳转这个功能时，无需使用这些函数，直接在模板文件橱url填"/入口文件名/模块/控制器/方法"。注意不要用url函数
    }
}
