<?php

namespace app\admin\controller;

use app\admin\common\Base;
use think\Request;
use think\Db;
use app\admin\model\Data2016;
use app\admin\model\Data2018;
use app\admin\model\Room_info as Info;
use app\admin\model\Room_type as Type;
use app\admin\model\Mode as Modetype;
use app\admin\model\Room_mode as Modeall;


class Mode extends Base
{
	
	public function search($date,$roomid){
		
		//dump($date);
		//dump($roomid);
		$this -> view -> assign('date_show_str', $date);
		
		$roomname = $roomid.'a';
		$room_name = Db::query("select name from room_info where id='$roomid'");
		$room_name_str=$room_name[0]['name'];
		$this -> view -> assign('room_name_str', $room_name_str);
		
		$data = Db::query("select * from room_data2016 where date='$date'");
		//dump($data);
		$data24=[$data[0][$roomname],$data[1][$roomname],$data[2][$roomname],$data[3][$roomname],$data[4][$roomname],
				$data[5][$roomname],$data[6][$roomname],$data[7][$roomname],$data[8][$roomname],$data[9][$roomname],
				$data[10][$roomname],$data[11][$roomname],$data[12][$roomname],$data[13][$roomname],$data[14][$roomname],
				$data[15][$roomname],$data[16][$roomname],$data[17][$roomname],$data[18][$roomname],$data[19][$roomname],
				$data[20][$roomname],$data[21][$roomname],$data[22][$roomname],$data[23][$roomname]];
		//dump($data24);
		
		$dataarray = array(
			'data'=>$data24,
			'name'=>$room_name_str
		);
		
		$datajson = json_encode($dataarray);
		file_put_contents('data24.json', $datajson);
		
		//查询用电模式模式数据
		$roomname2 = 'cell'.$roomid;
		
		
		$modedata = Db::query("select * from roommode_all where date='$date'");
		//dump($modedata);
		$modedata2 = $modedata[0][$roomname2];
		$modedata3 = Db::query("select * from room_mode where id='$modedata2'");
		$modedata4 = $modedata3[0]['mode'];
    	//dump($modedata2);
    	$this -> view -> assign('modedata4', $modedata4);
    	
    	//根据查到的日用电数据计算日总用电，判断用能水平
    	//用电模式为modedata2，
    	$day_elec = $data24[0]+$data24[1]+$data24[2]+$data24[3]+$data24[4]+$data24[5]
    				+$data24[6]+$data24[7]+$data24[8]+$data24[9]+$data24[10]+$data24[11]
    				+$data24[12]+$data24[13]+$data24[14]+$data24[15]+$data24[16]+$data24[17]
    				+$data24[18]+$data24[19]+$data24[20]+$data24[21]+$data24[22]+$data24[23] ;
    	$this -> view -> assign('day_elec', $day_elec);
    	
    	$room_type = Db::query("select type from room_info where id='$roomid'");
	    $room_type_id = $room_type[0]['type'];
	    $room_type_name = Db::query("select room_type from room_type where id='$room_type_id'");
	    $room_type_str = $room_type_name[0]['room_type'];
    	$this -> view -> assign('room_type_str', $room_type_str);
    	
    	
    	
    	if($modedata2 != 5){
    		   				
	    	
	    	//根据房间类型和用能模式查询能耗水平线
	    	$level= Db::query("select * from roomlevel_14 where type_id='$room_type_id'");
	    	$mode_low = $modedata2.'low';
	    	$mode_high = $modedata2.'high';
	    	$low = $level[0][$mode_low];
	    	$high = $level[0][$mode_high];
	    	if($day_elec <= $low){
	    		$level_result_id = 1;
	    	}else if($day_elec >= $high){
	    		$level_result_id = 3;
	    	}else{
	    		$level_result_id = 2;
	    	}
    	}else{
    		$level_result_id = 4;
    	}
    	$miaoshu = Db::query("select * from room_level where id='$level_result_id'");
    	$level_level = $miaoshu[0]['level'];
    	//$level_miaoshu = $miaoshu[0]['miaoshu']
    	$this -> view -> assign('level_level', $level_level);
    	//$this -> view -> assign('level_miaoshu', $level_miaoshu);
    	
		
//		return $this->redirect('mode/mode', ['data' => $data24 , 'room_name_str'=>$room_name_str]);
		return $this->view->fetch('mode');
		
//		$data = $_POST['data'];
//		//$data = $request->param();
//		dump($data);
//		dump('tiaoshi');
		
		//$date = $date['date'];
		//dump($date);
		
		
//		$data000 = $_POST;
//      $date = $data000;
//      dump($date);
//      $dateid = Db::query('select date_id from room_data2016 where date="$date" ');
//      dump($dateid);
//      $dateid_int=$dateid[0]['date_id'];
//		$hour = Db::query("select hour from room_data2016 where date_id='$dateid_int' ORDER by hour DESC limit 0,1");
//		$hour_int = $hour[0]['hour'];
//		if($hour_int=23){
//			$dateid_latest_complete = $dateid_int;
//		}else{
//			$dateid_latest_complete = $dateid_int-1;
//		}
//		$data = Db::query("select *from room_data2016 where date_id='$dateid_latest_complete'");
//		$data24=[$data[0][$roomname],$data[1][$roomname],$data[2][$roomname],$data[3][$roomname],$data[4][$roomname],
//				$data[5][$roomname],$data[6][$roomname],$data[7][$roomname],$data[8][$roomname],$data[9][$roomname],
//				$data[10][$roomname],$data[11][$roomname],$data[12][$roomname],$data[13][$roomname],$data[14][$roomname],
//				$data[15][$roomname],$data[16][$roomname],$data[17][$roomname],$data[18][$roomname],$data[19][$roomname],
//				$data[20][$roomname],$data[21][$roomname],$data[22][$roomname],$data[23][$roomname]];
//				
//		return ['data24'=>$data24];
        
	}
	
	public function modedata(){
		
		$dataJson = file_get_contents('data24.json');
		$dataArray = json_decode($dataJson, true);
		//dump($dataArray);
		$data=$dataArray['data'];
		//dump($data);
		$name=$dataArray['name'];
		return ['data'=>$data,'name'=>$name];
		//return $dataJson;
		
//		
////		echo $roomid;
////		
////		$modedata=Data2016::get(['id'=> $roomid]);
////		$this -> view -> assign('modedata', $modedata);
////		dump($modedata);
//
//		//拼凑字段名
//		$roomname=$roomid.'a';
//		echo $roomname;  //测试字段名是否输出正确
//		//获取最近一条记录中的日期id
//		$dateid = Db::query('select date_id from room_data2016 ORDER by id DESC limit 0,1');
//		dump($dateid);//查看查询结果
//		echo $dateid[0]['date_id'];  //测试dateid的单独输出
//		$dateid_int=$dateid[0]['date_id'];
//		$hour = Db::query("select hour from room_data2016 where date_id='$dateid_int' ORDER by hour DESC limit 0,1");
//		dump($hour);
//		$hour_int = $hour[0]['hour'];
//		if($hour_int=23){
//			$dateid_latest_complete = $dateid_int;
//		}else{
//			$dateid_latest_complete = $dateid_int-1;
//		}
//		echo $dateid_latest_complete;
//		$data = Db::query("select *from room_data2016 where date_id='$dateid_latest_complete'");
//		//奇怪的是，select '$roomname'无法获得预期效果
//		dump($data);
//		$data24=[$data[0][$roomname],$data[1][$roomname],$data[2][$roomname],$data[3][$roomname],$data[4][$roomname],
//				$data[5][$roomname],$data[6][$roomname],$data[7][$roomname],$data[8][$roomname],$data[9][$roomname],
//				$data[10][$roomname],$data[11][$roomname],$data[12][$roomname],$data[13][$roomname],$data[14][$roomname],
//				$data[15][$roomname],$data[16][$roomname],$data[17][$roomname],$data[18][$roomname],$data[19][$roomname],
//				$data[20][$roomname],$data[21][$roomname],$data[22][$roomname],$data[23][$roomname]];
//		dump($data24);
//		
//		
//		
//		$room_name = Db::query("select name from room_info where id='$roomid'");
//		dump($room_name);
//		$room_name_str=$room_name[0]['name'];
//		$this -> view -> assign('room_name_str', $room_name_str);
//		echo $room_name_str;
//		
//		
//  	
//		return ['data'=>$data24];
		
		
		//return $this->view->fetch('mode');
		
	}
	
	public function mode18($roomid){
		//拼凑字段名
		$roomname=$roomid.'a';
		//获取最近一条记录中的日期id
		$dateid = Db::query('select date_id from room_data2018 ORDER by id DESC limit 0,1');
		$dateid_int=$dateid[0]['date_id'];
		$hour = Db::query("select hour from room_data2018 where date_id='$dateid_int' ORDER by hour DESC limit 0,1");
		$hour_int = $hour[0]['hour'];
		if($hour_int=23){
			$dateid_latest_complete = $dateid_int;
		}else{
			$dateid_latest_complete = $dateid_int-1;
		}
		$data = Db::query("select *from room_data2018 where date_id='$dateid_latest_complete'");
		$data24=[$data[0][$roomname],$data[1][$roomname],$data[2][$roomname],$data[3][$roomname],$data[4][$roomname],
				$data[5][$roomname],$data[6][$roomname],$data[7][$roomname],$data[8][$roomname],$data[9][$roomname],
				$data[10][$roomname],$data[11][$roomname],$data[12][$roomname],$data[13][$roomname],$data[14][$roomname],
				$data[15][$roomname],$data[16][$roomname],$data[17][$roomname],$data[18][$roomname],$data[19][$roomname],
				$data[20][$roomname],$data[21][$roomname],$data[22][$roomname],$data[23][$roomname]];
				
		$room_name = Db::query("select name from room_info where id='$roomid'");
		$room_name_str=$room_name[0]['name'];
		
		$dataarray = array(
			'data'=>$data24,
			'name'=>$room_name_str
		);
		//dump($dataarray);
		$datajson = json_encode($dataarray);
		//dump($datajson);
		file_put_contents('data24.json', $datajson);
		
//		return $this->redirect('mode/mode', ['data' => $data24 , 'room_name_str'=>$room_name_str]);
		return $this->view->fetch('mode18');
	}
	
	public function mode($roomid){
		//拼凑字段名
		$roomname=$roomid.'a';
		//获取最近一条记录中的日期id
		$dateid = Db::query('select date_id from room_data2016 ORDER by id DESC limit 0,1');
		$dateid_int=$dateid[0]['date_id'];
		
		$date_show = Db::query("select date from room_data2016 WHERE date_id='$dateid_int'   ");
		$date_show_str = $date_show[0]['date'];
		$this -> view -> assign('date_show_str', $date_show_str);
		
		$hour = Db::query("select hour from room_data2016 where date_id='$dateid_int' ORDER by hour DESC limit 0,1");
		$hour_int = $hour[0]['hour'];
		if($hour_int=23){
			$dateid_latest_complete = $dateid_int;
		}else{
			$dateid_latest_complete = $dateid_int-1;
		}
		$data = Db::query("select *from room_data2016 where date_id='$dateid_latest_complete'");
		$data24=[$data[0][$roomname],$data[1][$roomname],$data[2][$roomname],$data[3][$roomname],$data[4][$roomname],
				$data[5][$roomname],$data[6][$roomname],$data[7][$roomname],$data[8][$roomname],$data[9][$roomname],
				$data[10][$roomname],$data[11][$roomname],$data[12][$roomname],$data[13][$roomname],$data[14][$roomname],
				$data[15][$roomname],$data[16][$roomname],$data[17][$roomname],$data[18][$roomname],$data[19][$roomname],
				$data[20][$roomname],$data[21][$roomname],$data[22][$roomname],$data[23][$roomname]];
				
		$room_name = Db::query("select name from room_info where id='$roomid'");
		$room_name_str=$room_name[0]['name'];
		$this -> view -> assign('room_name_str', $room_name_str);
		
		$dataarray = array(
			'data'=>$data24,
			'name'=>$room_name_str
		);
		//dump($dataarray);
		$datajson = json_encode($dataarray);
		//dump($datajson);
		file_put_contents('data24.json', $datajson);
		
		
		
		//查询用电模式模式数据
		$roomname2 = 'cell'.$roomid;
		$date = Db::query("select date from room_data2016 where date_id='$dateid_latest_complete'");
		$date_latest = $date[0]['date'];
		
		$modedata = Db::query("select * from roommode_all where date='$date_latest'");
		//dump($modedata);
		$modedata2 = $modedata[0][$roomname2];
		$modedata3 = Db::query("select * from room_mode where id='$modedata2'");
		$modedata4 = $modedata3[0]['mode'];
    	//dump($modedata2);
    	$this -> view -> assign('modedata4', $modedata4);
    	
    	//根据查到的日用电数据计算日总用电，判断用能水平
    	//用电模式为modedata2，
    	$day_elec = $data24[0]+$data24[1]+$data24[2]+$data24[3]+$data24[4]+$data24[5]
    				+$data24[6]+$data24[7]+$data24[8]+$data24[9]+$data24[10]+$data24[11]
    				+$data24[12]+$data24[13]+$data24[14]+$data24[15]+$data24[16]+$data24[17]
    				+$data24[18]+$data24[19]+$data24[20]+$data24[21]+$data24[22]+$data24[23] ;
    	$this -> view -> assign('day_elec', $day_elec);
    	
    	$room_type = Db::query("select type from room_info where id='$roomid'");
	    $room_type_id = $room_type[0]['type'];
	    $room_type_name = Db::query("select room_type from room_type where id='$room_type_id'");
	    $room_type_str = $room_type_name[0]['room_type'];
    	$this -> view -> assign('room_type_str', $room_type_str);
    	
    	
    	
    	if($modedata2 != 5){
    		   				
	    	
	    	//根据房间类型和用能模式查询能耗水平线
	    	$level= Db::query("select * from roomlevel_14 where type_id='$room_type_id'");
	    	$mode_low = $modedata2.'low';
	    	$mode_high = $modedata2.'high';
	    	$low = $level[0][$mode_low];
	    	$high = $level[0][$mode_high];
	    	if($day_elec <= $low){
	    		$level_result_id = 1;
	    	}else if($day_elec >= $high){
	    		$level_result_id = 3;
	    	}else{
	    		$level_result_id = 2;
	    	}
    	}else{
    		$level_result_id = 4;
    	}
    	$miaoshu = Db::query("select * from room_level where id='$level_result_id'");
    	$level_level = $miaoshu[0]['level'];
    	//$level_miaoshu = $miaoshu[0]['miaoshu']
    	$this -> view -> assign('level_level', $level_level);
    	//$this -> view -> assign('level_miaoshu', $level_miaoshu);
    	
		
//		return $this->redirect('mode/mode', ['data' => $data24 , 'room_name_str'=>$room_name_str]);
		return $this->view->fetch('mode');
	}
	
	public function mode1()
    {    
    	$mode10 =Info::get(['id' => '1']);
    	$this -> view -> assign('mode10', $mode10);
    	$mode11 =Info::get(['id' => '2']);
    	$this -> view -> assign('mode11', $mode11);
    	$mode12 =Info::get(['id' => '3']);
    	$this -> view -> assign('mode12', $mode12);
    	$mode13 =Info::get(['id' => '4']);
    	$this -> view -> assign('mode13', $mode13);
    	$mode14 =Info::get(['id' => '5']);
    	$this -> view -> assign('mode14', $mode14);
    	$mode15 =Info::get(['id' => '6']);
    	$this -> view -> assign('mode15', $mode15);
    	$mode16 =Info::get(['id' => '7']);
    	$this -> view -> assign('mode16', $mode16);
    	$mode17 =Info::get(['id' => '8']);
    	$this -> view -> assign('mode17', $mode17);
    	$mode18 =Info::get(['id' => '9']);
    	$this -> view -> assign('mode18', $mode18);
    	$mode19 =Info::get(['id' => '10']);
    	$this -> view -> assign('mode19', $mode19);
    	
    	$data16 = Db::query('select * from room_data2016 ORDER by id DESC limit 0,1');
    	$this -> view -> assign('data16', $data16);
    	
    	//查询信息表内共有多少条数据
    	$total = Db::query('select id from room_info ORDER by id DESC limit 0,1');
    	//dump($total);   	
    	$this -> view -> assign('total', $total);
    	
//  	$lists = Menu::paginate(10);
//      $this->assign('lists', $lists);
//      return $this->fetch();
	//下面这些是放在模板中的
	
//    		<div>
//				{volist name='lists' id='vo'}
//				    <li> {$vo.name}</li>
//				{/volist}
//			</div>
//			{$lists->render()}
    	
    		
        return $this->view->fetch('mode1');
    }
    
    public function mode2()
    {  
    	$mode20 =Info::get(['id' => '11']);
    	$this -> view -> assign('mode20', $mode20);
    	$mode21 =Info::get(['id' => '12']);
    	$this -> view -> assign('mode21', $mode21);
    	$mode22 =Info::get(['id' => '13']);
    	$this -> view -> assign('mode22', $mode22);
    	$mode23 =Info::get(['id' => '14']);
    	$this -> view -> assign('mode23', $mode23);
    	$mode24 =Info::get(['id' => '15']);
    	$this -> view -> assign('mode24', $mode24);
    	$mode25 =Info::get(['id' => '16']);
    	$this -> view -> assign('mode25', $mode25);
    	$mode26 =Info::get(['id' => '17']);
    	$this -> view -> assign('mode26', $mode26);
    	$mode27 =Info::get(['id' => '18']);
    	$this -> view -> assign('mode27', $mode27);
    	$mode28 =Info::get(['id' => '19']);
    	$this -> view -> assign('mode28', $mode28);
    	$mode29 =Info::get(['id' => '20']);
    	$this -> view -> assign('mode29', $mode29);
    	
    	$data16 = Db::query('select * from room_data2016 ORDER by id DESC limit 0,1');
    	$this -> view -> assign('data16', $data16);
    	
    	//查询信息表内共有多少条数据
    	$total = Db::query('select id from room_info ORDER by id DESC limit 0,1');
    	//dump($total);
    	
    	$this -> view -> assign('total', $total);
    	  	
        return $this->view->fetch('mode2');
    }
    
    public function mode3()
    {   
    	$mode30 =Info::get(['id' => '21']);
    	$this -> view -> assign('mode30', $mode30);
    	$mode31 =Info::get(['id' => '22']);
    	$this -> view -> assign('mode31', $mode31);
    	$mode32 =Info::get(['id' => '23']);
    	$this -> view -> assign('mode32', $mode32);
    	$mode33 =Info::get(['id' => '24']);
    	$this -> view -> assign('mode33', $mode33);
    	$mode34 =Info::get(['id' => '25']);
    	$this -> view -> assign('mode34', $mode34);
    	$mode35 =Info::get(['id' => '26']);
    	$this -> view -> assign('mode35', $mode35);
    	$mode36 =Info::get(['id' => '27']);
    	$this -> view -> assign('mode36', $mode36);
    	$mode37 =Info::get(['id' => '28']);
    	$this -> view -> assign('mode37', $mode37);
    	$mode38 =Info::get(['id' => '29']);
    	$this -> view -> assign('mode38', $mode38);
    	$mode39 =Info::get(['id' => '30']);
    	$this -> view -> assign('mode39', $mode39);
    	
    	$data16 = Db::query('select * from room_data2016 ORDER by id DESC limit 0,1');
    	$this -> view -> assign('data16', $data16);
    	
    	//查询信息表内共有多少条数据
    	$total = Db::query('select id from room_info ORDER by id DESC limit 0,1');
    	//dump($total);
    	
    	$this -> view -> assign('total', $total);
    	 	
        return $this->view->fetch('mode3');
    }
    
    public function mode4()
    {    
    	$mode40 =Info::get(['id' => '31']);
    	$this -> view -> assign('mode40', $mode40);
    	$mode41 =Info::get(['id' => '32']);
    	$this -> view -> assign('mode41', $mode41);
    	$mode42 =Info::get(['id' => '33']);
    	$this -> view -> assign('mode42', $mode42);
    	$mode43 =Info::get(['id' => '34']);
    	$this -> view -> assign('mode43', $mode43);
    	$mode44 =Info::get(['id' => '35']);
    	$this -> view -> assign('mode44', $mode44);
    	$mode45 =Info::get(['id' => '36']);
    	$this -> view -> assign('mode45', $mode45);
    	$mode46 =Info::get(['id' => '37']);
    	$this -> view -> assign('mode46', $mode46);
    	$mode47 =Info::get(['id' => '38']);
    	$this -> view -> assign('mode47', $mode47);
    	$mode48 =Info::get(['id' => '39']);
    	$this -> view -> assign('mode48', $mode48);
    	$mode49 =Info::get(['id' => '40']);
    	$this -> view -> assign('mode49', $mode49);
    	
    	$data16 = Db::query('select * from room_data2016 ORDER by id DESC limit 0,1');
    	$this -> view -> assign('data16', $data16);
    	
    	//查询信息表内共有多少条数据
    	$total = Db::query('select id from room_info ORDER by id DESC limit 0,1');
    	//dump($total);
    	
    	$this -> view -> assign('total', $total);
    		
        return $this->view->fetch('mode4');
    }
    
    public function mode5()
    {   
    	$mode50 =Info::get(['id' => '41']);
    	$this -> view -> assign('mode50', $mode50);
    	$mode51 =Info::get(['id' => '42']);
    	$this -> view -> assign('mode51', $mode51);
    	$mode52 =Info::get(['id' => '43']);
    	$this -> view -> assign('mode52', $mode52);
    	$mode53 =Info::get(['id' => '44']);
    	$this -> view -> assign('mode53', $mode53);
    	$mode54 =Info::get(['id' => '45']);
    	$this -> view -> assign('mode54', $mode54);
    	$mode55 =Info::get(['id' => '46']);
    	$this -> view -> assign('mode55', $mode55);
    	$mode56 =Info::get(['id' => '47']);
    	$this -> view -> assign('mode56', $mode56);
    	$mode57 =Info::get(['id' => '48']);
    	$this -> view -> assign('mode57', $mode57);
    	$mode58 =Info::get(['id' => '49']);
    	$this -> view -> assign('mode58', $mode58);
    	$mode59 =Info::get(['id' => '50']);
    	$this -> view -> assign('mode59', $mode59);
    	
    	$data16 = Db::query('select * from room_data2016 ORDER by id DESC limit 0,1');
    	$this -> view -> assign('data16', $data16);
    	
    	//查询信息表内共有多少条数据
    	$total = Db::query('select id from room_info ORDER by id DESC limit 0,1');
    	//dump($total);
    	
    	$this -> view -> assign('total', $total);
    	 	
        return $this->view->fetch('mode5');
    }
    
    public function mode6()
    {    
    	$mode60 =Info::get(['id' => '51']);
    	$this -> view -> assign('mode60', $mode60);
    	$mode61 =Info::get(['id' => '52']);
    	$this -> view -> assign('mode61', $mode61);
    	$mode62 =Info::get(['id' => '53']);
    	$this -> view -> assign('mode62', $mode62);
    	$mode63 =Info::get(['id' => '54']);
    	$this -> view -> assign('mode63', $mode63);
    	$mode64 =Info::get(['id' => '55']);
    	$this -> view -> assign('mode64', $mode64);
    	$mode65 =Info::get(['id' => '56']);
    	$this -> view -> assign('mode65', $mode65);
    	$mode66 =Info::get(['id' => '57']);
    	$this -> view -> assign('mode66', $mode66);
    	$mode67 =Info::get(['id' => '58']);
    	$this -> view -> assign('mode67', $mode67);
    	$mode68 =Info::get(['id' => '59']);
    	$this -> view -> assign('mode68', $mode68);
    	$mode69 =Info::get(['id' => '60']);
    	$this -> view -> assign('mode69', $mode69);
    	
    	$data16 = Db::query('select * from room_data2016 ORDER by id DESC limit 0,1');
    	$this -> view -> assign('data16', $data16);
    	
    	//查询信息表内共有多少条数据
    	$total = Db::query('select id from room_info ORDER by id DESC limit 0,1');
    	//dump($total);
    	
    	$this -> view -> assign('total', $total);
    		
        return $this->view->fetch('mode6');
    }
    
    public function mode7()
    {    
    	$mode70 =Info::get(['id' => '61']);
    	$this -> view -> assign('mode70', $mode70);
    	$mode71 =Info::get(['id' => '62']);
    	$this -> view -> assign('mode71', $mode71);
    	$mode72 =Info::get(['id' => '63']);
    	$this -> view -> assign('mode72', $mode72);
    	$mode73 =Info::get(['id' => '64']);
    	$this -> view -> assign('mode73', $mode73);
    	$mode74 =Info::get(['id' => '65']);
    	$this -> view -> assign('mode74', $mode74);
    	$mode75 =Info::get(['id' => '66']);
    	$this -> view -> assign('mode75', $mode75);
    	$mode76 =Info::get(['id' => '67']);
    	$this -> view -> assign('mode76', $mode76);
    	$mode77 =Info::get(['id' => '68']);
    	$this -> view -> assign('mode77', $mode77);
    	$mode78 =Info::get(['id' => '69']);
    	$this -> view -> assign('mode78', $mode78);
    	$mode79 =Info::get(['id' => '70']);
    	$this -> view -> assign('mode79', $mode79);
    	
    	
    	$data16 = Db::query('select * from room_data2016 ORDER by id DESC limit 0,1');
    	$this -> view -> assign('data16', $data16);
    	//查询信息表内共有多少条数据
    	$total = Db::query('select id from room_info ORDER by id DESC limit 0,1');
    	//dump($total);
    	
    	$this -> view -> assign('total', $total);
    		
        return $this->view->fetch('mode7');
    }
    
    public function mode8()
    {    
    	$mode80 =Info::get(['id' => '71']);
    	$this -> view -> assign('mode80', $mode80);
    	$mode81 =Info::get(['id' => '72']);
    	$this -> view -> assign('mode81', $mode81);
    	$mode82 =Info::get(['id' => '73']);
    	$this -> view -> assign('mode82', $mode82);
    	$mode83 =Info::get(['id' => '74']);
    	$this -> view -> assign('mode83', $mode83);
    	$mode84 =Info::get(['id' => '75']);
    	$this -> view -> assign('mode84', $mode84);
    	$mode85 =Info::get(['id' => '76']);
    	$this -> view -> assign('mode85', $mode85);
    	$mode86 =Info::get(['id' => '77']);
    	$this -> view -> assign('mode86', $mode86);
    	$mode87 =Info::get(['id' => '78']);
    	$this -> view -> assign('mode87', $mode87);
    	$mode88 =Info::get(['id' => '79']);
    	$this -> view -> assign('mode88', $mode88);
    	$mode89 =Info::get(['id' => '80']);
    	$this -> view -> assign('mode89', $mode89);
    	
    	$data16 = Db::query('select * from room_data2016 ORDER by id DESC limit 0,1');
    	$maxnum = $data16[0]['id'];  //获取总记录条数
    	//dump($maxnum);
    	$data_i = Db::query("select * from room_data2016 where id='$maxnum' ");
    	//dump($data_i);
    	$this -> view -> assign('data_i', $data_i);
    	
    	
    	
    	$data18 = Db::query('select * from room_data2018 ORDER by id DESC limit 0,1');
    	$this -> view -> assign('data18', $data18);
    	
    	//查询信息表内共有多少条数据
    	$total = Db::query('select id from room_info ORDER by id DESC limit 0,1');
    	//dump($total);   	
    	$this -> view -> assign('total', $total);
    		
        return $this->view->fetch('mode8');
        
//      for($i=$maxnum;$i>0;$i--){
//  		$data_i = Db::query('select * from room_data2016 where id="$i" ');
//  		$this -> view -> assign('data_i', $data_i);
//  		sleep(2);
//  	}
    }
    
    public function mode9()
    {    
    	$mode90 =Info::get(['id' => '81']);
    	$this -> view -> assign('mode90', $mode90);
    	$mode91 =Info::get(['id' => '82']);
    	$this -> view -> assign('mode91', $mode91);
    	$mode92 =Info::get(['id' => '83']);
    	$this -> view -> assign('mode92', $mode92);
    	$mode93 =Info::get(['id' => '84']);
    	$this -> view -> assign('mode93', $mode93);
    	$mode94 =Info::get(['id' => '85']);
    	$this -> view -> assign('mode94', $mode94);
    	$mode95 =Info::get(['id' => '86']);
    	$this -> view -> assign('mode95', $mode95);
    	$mode96 =Info::get(['id' => '87']);
    	$this -> view -> assign('mode96', $mode96);
    	$mode97 =Info::get(['id' => '88']);
    	$this -> view -> assign('mode97', $mode97);
    	$mode98 =Info::get(['id' => '89']);
    	$this -> view -> assign('mode98', $mode98);
    	$mode99 =Info::get(['id' => '90']);
    	$this -> view -> assign('mode99', $mode99);
    	
    	$data18 = Db::query('select * from room_data2018 ORDER by id DESC limit 0,1');
    	$this -> view -> assign('data18', $data18);
    	
    	//查询信息表内共有多少条数据
    	$total = Db::query('select id from room_info ORDER by id DESC limit 0,1');
    	//dump($total);
    	
    	$this -> view -> assign('total', $total);
    		
        return $this->view->fetch('mode9');
    }
   
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function index()
    {
        //
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request  $request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * 显示指定的资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function delete($id)
    {
        //
    }
}
