<?php

namespace app\admin\controller;

use app\admin\common\Base;
use think\Request;
use app\admin\model\Admin;
use think\Session;
use think\Db;
//use think\Db;

class Login extends Base
{
    //渲染登录界面
    public function index()
    {
        $this -> alreadyLogin();
        return $this->view->fetch('login');
    }
    
    public function check(Request $request)
    {
        /*
        $list = Db::table('admin')
    		->where('id',1)
    		->select();
    	dump($list);
    	$message=$list;
        */
        //设置status
        $status = 0;
        
        //获取表单提交的数据并保存在变量中
        $data = $request->param();
        $administrator = $data['administrator'];  //这里的'administrator'指的是表单提交的；而$administrator是用来保存表单数据的变量
        $password = md5($data['password']);   //同理。   md5 32位密码加密
        
        //在admin数据表中进行查询       
        $map=['administrator'=>$administrator];    //这里的'administrator'指的是mysql中admin数据表里的administrator字段
        //$admin=Admin::get($map);
        $admin=Admin::get($map);
        
        //将用户名和密码分开验证
        
        //如果没有查询到该用户
        if(is_null($admin)){
        	//设置返回信息
        	$message='用户名不存在！';
        }elseif($admin->password !=$password){
        	$message='密码不正确！';
        }else{
        	//用户名和密码都通过验证，表明是合法用户
        	//修改返回信息
        	$status = 1;
        	$message='验证通过，请点击确定进入后台';
        	
        	//更新数据表中登陆次数和最后登录时间
        	$admin ->setInc('login_count');
        	$admin ->save(['last_time'=>time()]);
        	
        	//为了后面Admin部分能获取到表的其他信息，这里设置一个变量用来存储查询的数据表整行信息
        	//先试下在下面的session里边是否能够存入对象，即上面的$admin。对象中调用某个字段的形式是$admin.xxx。测试的结果是session中确实有数据，但是太乱了
        	//而按照原本的session范例，存储的应该是数组元素，假设如下创建一个$row数组,其调用里边元素形式为$row['xxx']
        	//要想以数组形式获取数据表数据应使用Db类，如下
        	$row = Db::query('select * from admin where administrator=?',[$administrator]);//查看数据库查询中的参数绑定部分
        	
        	//将用户的登录信息保存在session（会话）中，供其他控制器使用
        	Session::set('user_id',$administrator);
        	Session::set('user_info',$row);
        	
        }
        
        return ['status'=>$status,'message'=>$message];
    }
    
    public function logout()
    {
        //删除当前用户session值
        Session::delete('user_id');
        Session::delete('user_info');
        
        //执行成功，并返回登录界面
        $this->success('注销成功，正在返回...','login/index');
    }
    
    
    
    
    
    
    
    
    
    
    
    
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request  $request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * 显示指定的资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function delete($id)
    {
        //
    }
}
