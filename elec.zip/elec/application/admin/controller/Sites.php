<?php

namespace app\admin\controller;

use app\admin\common\Base;
use think\Request;
use app\admin\model\Sites as MySites;
use app\admin\model\Site1 as Site1Data;
use app\admin\model\Site2 as Site2Data;
use app\admin\model\Site3 as Site3Data;
use think\Db;

class Sites extends Base
{
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function index()
    {
    	
    	$site1 =MySites::get(['id' => '1']);
    	$this -> view -> assign('site1', $site1); 
    	
    	$site2 =MySites::get(['id' => '2']);
    	$this -> view -> assign('site2', $site2);
    	
    	$site3 =MySites::get(['id' => '3']);
    	$this -> view -> assign('site3', $site3);
    	
    	
        return $this->view->fetch('site-list');
    }
    
    public function site_add()
    {
        return $this->view->fetch('site-add');
    }
    
    public function site1()
    {
    	//获取并渲染测点数据表信息
    	$site1 =MySites::get(['id' => '1']);
    	$this -> view -> assign('site1', $site1);
        return $this->view->fetch('site1');
    }
    
    public function site2()
    {
    	//获取并渲染测点数据表信息
    	$site2 =MySites::get(['id' => '2']);
    	$this -> view -> assign('site2', $site2);
        return $this->view->fetch('site2');
    }
    
    public function site3()
    {
    	//获取并渲染测点数据表信息
    	$site3 =MySites::get(['id' => '3']);
    	$this -> view -> assign('site3', $site3);
    	
//  	//---------------------------------------------------------------------------------
//  	$a=array();
//		$b=array(); $c=array(); $d=array(); $e=array(); $f=array(); $g=array();
//		$list =Site3Data::all();
//		foreach($list as $my_site3){
//			//向一个数组中末尾添加元素有两种方法：
//			//1、使用array_push($array,$value)
//			//2、直接array[]=$value，这样效率更快
//			$a[] = $my_site3->id;
//			$b[] = $my_site3->date;
//			$c[] = $my_site3->time;
//			$d[] = $my_site3->realtime_elec;
//			$e[] = $my_site3->delta_elec;
//			$f[] = $my_site3->timestamp;
//		};
//		
//		$arrayLength = count($f);
//		for($i=0;$i<$arrayLength;$i++){
//			$g[] = date("Y-m-d H:i:s",$f[$i]);
//		};
//		//创建一个关联数组，其中只有7个元素，即上面的7个数组
//		$site3_data_array = array("id"=>$a,"date"=>$b,"time"=>$c,"realtime_elec"=>$d,"delta_elec"=>$e,"timestamp"=>$f,"date_time"=>$g);
//		
//		//转换成json对象
//		$site3_data = json_encode($site3_data_array);
//		//写入json文件。如果存在同名文件则会覆盖，正是我们需要的
//		file_put_contents('site3.json',$site3_data);
//		//-----------------------------------------------------------------------------------------------------------
//  	
    	
    	//在生成了json之后才渲染网页模板，这样在网页加载时就能够在服务器获取到.json文件了
        return $this->view->fetch('site3');
    }
    
    public function site1_json(){
    	$a=array(); $b=array(); $c=array(); $d=array(); $e=array(); $f=array(); $g=array();
    	
    	$list =Site1Data::all();
		foreach($list as $my_site1){
			$a[] = $my_site1->id;
			$b[] = $my_site1->date;
			$c[] = $my_site1->time;
			$d[] = $my_site1->realtime_elec;
			$e[] = $my_site1->delta_elec;
			$f[] = $my_site1->timestamp;
		};
		
		$arrayLength = count($f);
		for($i=0;$i<$arrayLength;$i++){
			$g[] = date("Y-m-d H:i:s",$f[$i]);
		};
		
		return ["id"=>$a,"date"=>$b,"time"=>$c,"realtime_elec"=>$d,"delta_elec"=>$e,"timestamp"=>$f,"date_time"=>$g];
    }
    
    public function site2_json(){
    	$a=array(); $b=array(); $c=array(); $d=array(); $e=array(); $f=array(); $g=array();
    	
    	$list =Site2Data::all();
		foreach($list as $my_site2){
			$a[] = $my_site2->id;
			$b[] = $my_site2->date;
			$c[] = $my_site2->time;
			$d[] = $my_site2->realtime_elec;
			$e[] = $my_site2->delta_elec;
			$f[] = $my_site2->timestamp;
		};
		
		$arrayLength = count($f);
		for($i=0;$i<$arrayLength;$i++){
			$g[] = date("Y-m-d H:i:s",$f[$i]);
		};
		
		return ["id"=>$a,"date"=>$b,"time"=>$c,"realtime_elec"=>$d,"delta_elec"=>$e,"timestamp"=>$f,"date_time"=>$g];
    }
    
    
    public function site3_json(){
    	//获取数据表中所有行数据，以json形式输出
//  	$list =Site3Data::all();//这里的$list是数组  	
//  	$site3_data = json_encode($list);   	
//  	echo $site3_data;
//      采用上面的方法，可以在调用后得到的site3_json.html中看到有数据，但其中是以行为单元
    	
    	//query返回的是数组
//  	$result1 = Db::query("select date from 24h_elec");
//  	$result2 = Db::query("select time from 24h_elec");
//  	$result3 = Db::query("select realtime_elec from 24h_elec");
//  	$result4 = Db::query("select delta_elec from 24h_elec");
//  	
//  	//这里就只考虑两个数组等长，不去验证谁长谁短了
//  	$date_time=array();
//  	$arrayLength1=count($result1);
//  	for($i = 0;$i<$arrayLength1;$i++){
//  		$date_time[$i]= (string){$result1[$i]}+' '+(string){$result2[$i]};
//  	};
//  	
//  	$site3_Data = $date_time + $result3 + $result4;
//  	
//  	$site3_data = json_encode($site3_Data);
//  	
//  	echo $site3_data;

		$a=array();
		$b=array(); $c=array(); $d=array(); $e=array(); $f=array(); $g=array();
		
		
		
//----------------------------------------------------复杂查询参考下面的内容		
//		//1.构造闭包函数 
//		$closure = function ($query){          
//		 	//1.设置字段别名 
//		 	 $field['id'] = '编号';          
//		 	 $field['name'] = '姓名';          
//		 	 $field['age'] = '年龄';          
//		 	 $field['salary'] = '工资';          
//		 	 //2.设置查询表达式  
//		 	 $map['age'] = ['>',30]; 
//		 	 $map['salary'] = ['>',8000]; 
//
//	          //3.执行查询  
//	          $query -> field($field)  //限制显示字段 
//	          	-> where($map)    //过滤查询结果 
//	          	-> order('salary desc')  //按salary字段降序输出 
//	          	-> limit(3);   //限制输出数量 
//	    };      
//	    //2.执行闭包查询,返回数据对象数组  
//	    $result = Staff::all($closure); 
//
//    //3.遍历该数据对象数组:$result  //$data既是循环变量,也是其中一个数据对象  
//    foreach ($result as $data){      
//    	//getData()可以获取数据对象原始数据:$data属性值  
//    	dump($data -> getData());
//    }  
		
		
		
		//直接使用all方法
		$list =Site3Data::all();
		foreach($list as $my_site3){
			//向一个数组中末尾添加元素有两种方法：
			//1、使用array_push($array,$value)
			//2、直接array[]=$value，这样效率更快
			$a[] = $my_site3->id;
			$b[] = $my_site3->date;
			$c[] = $my_site3->time;
			$d[] = $my_site3->realtime_elec;
			$e[] = $my_site3->delta_elec;
			$f[] = $my_site3->timestamp;
		};
		
		$arrayLength = count($f);
		for($i=0;$i<$arrayLength;$i++){
			$g[] = date("Y-m-d H:i:s",$f[$i]);
		};
		
//		echo $a;
//		echo $b;echo $c;echo $d;echo $e;echo $f;echo $g;

		//创建一个关联数组，其中只有7个元素，即上面的7个数组
		//$site3_data_array = array("id"=>$a,"date"=>$b,"time"=>$c,"realtime_elec"=>$d,"delta_elec"=>$e,"timestamp"=>$f,"date_time"=>$g);
		
		//转换成json对象
		//$site3_data = json_encode($site3_data_array);
		
		//echo $site3_data;
		
		//return [''$site3_data];
		
		return ["id"=>$a,"date"=>$b,"time"=>$c,"realtime_elec"=>$d,"delta_elec"=>$e,"timestamp"=>$f,"date_time"=>$g];
		//默认返回json
    	
    	
    }
    
   
    public function search(Request $request)
    {
        $status=0;
        $message="11111";
        
        $data = $request->param();
  		    $start = $data['start'];
  		   $end = $data['end'];
		   $bianhao = $data['bianhao'];
        echo $start;
        if(!is_null($data)){
        	$message="2222";
        	$status=1;
        }
        return ["status"=>$status,"message"=>$message];
        
    }
    
   
   
   
   
   
   
   
    
    /**
     * 显示指定的资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }








    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request  $request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function delete($id)
    {
        //
    }
}
