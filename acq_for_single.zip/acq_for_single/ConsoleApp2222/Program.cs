﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Configuration;
using System.Data;
using MySql.Data;
using MySql.Data.MySqlClient;


namespace ConsoleApp2222
{
    public class SynchronousSocketClient
    {

        public static void StartClient()
        {
            // Data buffer for incoming data.  
            //byte[] bytes = new byte[1024];
            byte[] bytes = new byte[9];//这里考虑传回的modbus数据只有9个字节。例如010404436B580E25D8。作为十六进制数，一位代表四个bit。

            //定义电表地址数组，也即是电量采集数据表数组
            string[] modbus = new string[32];
            modbus[0] = "01040000000271CB";
            modbus[1] = "02040000000271F8";
            int i;
            for(i=2; i<32; i++)
            {
                modbus[i] = null;
            }

            //定义数据表表名数组，同时对应了电表的编号（一个电表放一个数据表）;数据表名：e01/e02/e03/,,,,,
            string[] tables = new string[32];
            tables[0] = "01040000000271CB";
            tables[1] = "02040000000271F8";
            int j;
            for (i = 0; i < 32; i++)
            {
                j = i + 1;
                tables[i] = "e0"+j;
            }

            


            // Connect to a remote device.  
            try
            {
                // Establish the remote endpoint for the socket.  
                // This example uses port 11000 on the local computer.  
                //IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
                //IPAddress ipAddress = ipHostInfo.AddressList[0];
                
                //通过外部配置文件对改程序作一些设置
                AppSettingsReader reader = new AppSettingsReader();
                string ip = Convert.ToString(reader.GetValue("serverIP", typeof(string)));
                int port = Convert.ToInt16(reader.GetValue("serverPort", typeof(int)));
                string modbus_command = Convert.ToString(reader.GetValue("ModbusCommand", typeof(string)));
                string testmsg = Convert.ToString(reader.GetValue("TestMessage", typeof(string)));
                bool receivecontrol = Convert.ToBoolean(reader.GetValue("ReceiveControl", typeof(bool)));

                int datastart = Convert.ToInt16(reader.GetValue("DataStart", typeof(int)));
                int datalength = Convert.ToInt16(reader.GetValue("DataLength", typeof(int)));
                

                //c从配置文件获取并解析ip、port
                IPAddress ipAddress = IPAddress.Parse(ip);
                IPEndPoint remoteEP = new IPEndPoint(ipAddress, port);

                // Create a TCP/IP  socket.  
                Socket sender = new Socket(ipAddress.AddressFamily,
                    SocketType.Stream, ProtocolType.Tcp);

                


                // Connect the socket to the remote endpoint. Catch any errors.  
                try
                {
                    sender.Connect(remoteEP);

                    Console.WriteLine("Socket connected to {0}\n\n",
                        sender.RemoteEndPoint.ToString());
                    //-------------------------------------------------------发送测试
                    // Encode the data string into a byte array.  
                    //在配置文件中填写testmsg可修改字符串发送内容
                    //填写command可发送十六进制指令
                    //发送测试
                    //byte[] msg = Encoding.ASCII.GetBytes(testmsg);
                    //int bytesSent = sender.Send(msg);



                    //----------------------------------------------------循环发送modbus指令接收modbus数据

                    for(i=0;i<32;i++)
                    {
                        int y = i + 1;
                        if(modbus[i]!=null)
                        {
                            byte[] command = HexStringToByteArray(modbus[i]);
                            // Send the data through the socket.  
                            int bytesSent2 = sender.Send(command);
                            Console.WriteLine("{0}号电表 | 已向电表发送指令：{1}", y,modbus[i]);

                            Thread.Sleep(1000);

                            //接收回传的数据
                            //配置文件中receivecontrol的true选择十六进制显示；false选择ASCII编码显示
                            int bytesRec = sender.Receive(bytes);
                            Console.WriteLine("{0}号电表 | 接收数据成功",y);
                            if (receivecontrol == false)
                            {
                                try
                                {
                                    Console.WriteLine("以ASCII编码显示：Echoed test = {0}",
                                    Encoding.ASCII.GetString(bytes, 0, bytesRec));
                                }
                                catch (Exception e1)
                                {
                                    Console.WriteLine("SocketException : {0}", e1.ToString());
                                }

                            }
                            else
                            {
                                try
                                {
                                    string bytes_display = ByteArrayToHexStringNoBlank(bytes);
                                    Console.WriteLine("{0}号电表 | 以十六进制显示：Echoed test = {1}", y,bytes_display);

                                    String UsefulData = SelectString(bytes_display, datastart, datalength);
                                    float floatnum = HEX2Float(UsefulData);
                                    Console.WriteLine("{0}号电表 | MODBUS解析后的数据为 {1}", y, floatnum);

                                    int id_now = Mysql_connector.GetId(tables[i]);
                                    Console.WriteLine("{0}号电表 | 当前数据id为：{1}", y,id_now);
                                    int id_soon = id_now + 1;

                                    decimal delta_elec = 0;
                                    if(id_now.ToString()!=null)//也就是说只要数据表此时有一条记录或以上都执行下面的getelec
                                    {
                                        decimal last_elec = Mysql_connector.GetElec(tables[i], 1, 1);//获取数据表倒数第一条数据
                                        delta_elec = (decimal)floatnum - last_elec;

                                    }
                                    else
                                    {
                                        delta_elec = 0;//当数据表为空，此时正要插入第一条时，自然delta_elec不存在（没有意义），赋值为0
                                    }
                                    Console.WriteLine("{0}号电表 | 上一个小时用电量为：{1}", y, delta_elec);

                                    Mysql_connector.mysql_connect_storage(tables[i],id_soon, (decimal)floatnum, delta_elec);

                                    Console.WriteLine("{0}号电表 | 当前数据已存入数据表{1}\n\n", y, tables[i]);



                                }
                                catch (Exception e2)
                                {
                                    Console.WriteLine("{0}号电表 | 第三层（最内层）SocketException : {1}", y,e2.ToString());
                                }


                            }

                        }
                    }

                    //延时一下，调试时用的
                    //Thread.Sleep(9999);//参数为32位int。延时指定毫秒数
                    //Application.doevent();

                    // Release the socket.  
                    //sender.Shutdown(SocketShutdown.Both);
                    //sender.Close();

                    //等待键盘输入。也是调试用的
                    //Console.ReadKey();

                }
                catch (ArgumentNullException ane)
                {
                    Console.WriteLine("第二层ArgumentNullException : {1}",ane.ToString());
                }
                catch (SocketException se)
                {
                    Console.WriteLine("第二层SocketException : {1}",se.ToString());
                }
                catch (Exception e)
                {
                    Console.WriteLine("第二层Unexpected exception : {1}",e.ToString());
                }

                // Release the socket.  
                sender.Shutdown(SocketShutdown.Both);
                sender.Close();


            }
            catch (Exception e)
            {
                Console.WriteLine("第一层（最外层）Unexpected exception : {1}",e.ToString());
            }

            //等待键盘输入。也是调试用的
            Console.ReadKey();


        }

        //16进制字符串转字节数组。（用户实际操作时输入的十六进制数本质上是字符串，但需要有程序将字符串转为字节数组让机器理解）
        //这是发送十六进制指令时需要用到的
        public static byte[] HexStringToByteArray(string s)
        {
            if (s.Length == 0)
                throw new Exception("将16进制字符串转换成字节数组时出错，错误信息：被转换的字符串长度为0。");
            s = s.Replace(" ", "");
            byte[] buffer = new byte[s.Length / 2];
            for (int i = 0; i < s.Length; i += 2)
                buffer[i / 2] = Convert.ToByte(s.Substring(i, 2), 16);
            return buffer;
        }

        
        // 字节数组转换成十六进制字符串(不带空格)  
      
        //<param name="data">要转换的字节数组</param>  
        // <returns>转换后的字符串</returns>  
        //这是接收到十六进制指令并将其显示出来给用户看时需要用到的
        public static string ByteArrayToHexStringNoBlank(byte[] data)
        {
            StringBuilder sb = new StringBuilder(data.Length * 3);
            foreach (byte b in data)
                sb.Append(Convert.ToString(b, 16).PadLeft(2, '0'));
            return sb.ToString().ToUpper();
        }

        //HEX转成浮点数
        public static float HEX2Float(string hexString)
        {
            uint num = uint.Parse(hexString, System.Globalization.NumberStyles.AllowHexSpecifier);

            byte[] floatVals = BitConverter.GetBytes(num);
            float f = BitConverter.ToSingle(floatVals, 0);
            
            return f;
        }

        //截取字符串自第i个字符起共j个字符
        public static string SelectString(string s,int i, int j)
        {
            string newstring = s.Substring(i - 1, j);
            return newstring;
        }

        public static int Main(String[] args)
        {
            StartClient();
            return 0;
        }
    }

    public class Mysql_connector
    {
        public static void mysql_connect_storage(string table, int id_soon,decimal realtime_elec ,decimal delta_elec)
        {
            MySqlConnection conn = null;//创建MySqlConnection类
            conn = new MySqlConnection("Server=localhost;Database=elec_monitor;Username=root;Password=");//创建连接字符串，提供连接数据库的必要信息
            conn.Open();//连接数据库

            if (conn.State.ToString() == "Open")//检测是否连接成功
            {
                Console.WriteLine("连接MySQL数据库成功");

                //获取当前日期与整点时间
                //string date = DateTime.Now.ToString("yyyy-MM-dd");        //例如 2008-09-04
                //string hour = DateTime.Now.Hour.ToString();
                //string time = hour + ":00:00";
                //DateTime date = DateTime.Now;

                DateTime currentTime = new DateTime();
                currentTime = DateTime.Now;
                int year = currentTime.Year;
                int month = currentTime.Month;
                int day = currentTime.Day;
                int hour = currentTime.Hour;

                int date = year * 10000 + month * 100 + day;
                int time = hour * 10000;

                //由于unix时间戳的转换需要考虑闰年因素，在这里假定使用环境为2018年，1970至2018年间的闰年数为12,2629763为一个月的平均秒数，这会产生一定的误差，因此还需要跟标准时间戳作差来给出一个修正值
                int xiuzhengzhi=-112029;
                int timestamp = ((year -1970)*365+12)*86400+(month-1)*2619743+(day-1)*86400+hour*3600+ xiuzhengzhi;
                //上面这个函数是正确的。但是C#专门获取时间戳的方法，如下：但这个是实时的、精确到秒的,因此还是采用自己写的这个
                //int timestamp = Convert.ToInt32((DateTime.Now.ToUniversalTime().Ticks - 621355968000000000) / 10000000);




                //拼接MySql插入指令语句
                StringBuilder mystringbuilder = new StringBuilder();
                mystringbuilder.Append("INSERT INTO ");
                mystringbuilder.Append(table);
                mystringbuilder.Append(" (id, date, time, realtime_elec, delta_elec,timestamp) VALUES(");
                mystringbuilder.Append(id_soon);
                mystringbuilder.Append(",");
                mystringbuilder.Append(date);
                mystringbuilder.Append(",");
                mystringbuilder.Append(time);
                mystringbuilder.Append(",");
                mystringbuilder.Append(realtime_elec);
                mystringbuilder.Append(",");
                mystringbuilder.Append(delta_elec);
                mystringbuilder.Append(",");
                mystringbuilder.Append(timestamp);
                mystringbuilder.Append(")");
                string cmd_insert = mystringbuilder.ToString();
                Console.WriteLine("发送的MySql插入数据指令为： {0}", cmd_insert);


                //发送insert指令并返回执行结果
                MySqlCommand cmd = new MySqlCommand(cmd_insert, conn);//创建MySqlCommand类，并提供SQL语句，以及要操作的 MySqlConnection对象
                Console.WriteLine("创建mysqlcommand类成功");
                int n = cmd.ExecuteNonQuery();//执行SQL语句，对连接的数据库进行操作，ExecuteNonQuery()方法不能用于查询语句
                Console.WriteLine("影响行数：" + n);//查看返回值，为影响到的行数

                //拼接select指令(查询当前数据表最近一条数据)
                string cmd_select = "select*from " + table+" ORDER by id desc limit 1" ;
                
                //查询表的更改情况
                cmd = new MySqlCommand(cmd_select, conn);
                MySqlDataReader dr;//如果想要使用查询语句，则应先创建MySqlDataReader类，此为ExecuteReader()方法的返回类型
                dr = cmd.ExecuteReader();//使用ExecuteReader()方法执行查询语句
                while (dr.Read())//使用Read()方法查询返回的MySqlDataReader对象中的数据，返回值为true或false
                {
                    Console.WriteLine("插入此时数据后数据表的最新一条为： "+dr["id"] + " " + dr["date"] + " " + dr["time"]+ " " + dr["realtime_elec"] + " " + dr["delta_elec"] + " " + dr["timestamp"]);//输出查询到的数据，dr["字段名"]，这里的字段名对应数据库查询的表中的字段名
                }
                dr.Close();//关键的一步，不要忘记关闭MySqlDataReader对象！！！！！

                /*
                Console.WriteLine("选择一种查询方式：1为使用MySqlDataReader类进行查询，2为使用ADO.NET(MySqlDataAdapter，DataSet，DataTable类)进行查询:");

                int s = Console.Read();
                if (s == '1')
                {
                    MySqlDataReader dr;//如果想要使用查询语句，则应先创建MySqlDataReader类，此为ExecuteReader()方法的返回类型
                    dr = cmd.ExecuteReader();//使用ExecuteReader()方法执行查询语句
                    while (dr.Read())//使用Read()方法查询返回的MySqlDataReader对象中的数据，返回值为true或false
                    {
                        Console.WriteLine(dr["id"] + " " + dr["name"]);//输出查询到的数据，dr["字段名"]，这里的字段名对应数据库查询的表中的字段名
                    }
                    dr.Close();//关键的一步，不要忘记关闭MySqlDataReader对象！！！！！
                }
                else if (s == '2')
                {
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);//第二种查询方式，使用MySqlDataAdapter对象
                    DataSet ds = new DataSet();//创建 DataSet对象
                    DataTable dt = new DataTable();//创建 DataTable对象
                    da.Fill(ds, "test");//调用Fill方法执行SQL语句，并将查询存入DataSet对象中
                    dt = ds.Tables["test"];//对数据库检索后，被取回的数据就存放在DataTable对象中
                    for (int i = 0; i < dt.Rows.Count; i++)//读取数据
                    {
                        Console.WriteLine(dt.Rows[i]["id"].ToString() + " " + dt.Rows[i]["name"].ToString());
                    }
                }
                */

            }
            else
            {
                Console.WriteLine("连接失败");
            }
            conn.Close();//关键的一步，不要忘记关闭连接！！！！！
        }

        //读取数据表倒数第m条起n个数据中的realtime_elec
        public static decimal GetElec(string tablename, int m,int n)
        {
            int x = m - 1;//因为id默认从0开始，所以进行这样的转换
            string cmd_select_get = "select*from " + tablename + " ORDER by id desc limit "+ x +","+ n;
            decimal f=0;

            MySqlConnection conn = null;//创建MySqlConnection类
            conn = new MySqlConnection("Server=localhost;Database=elec_monitor;Username=root;Password=");//创建连接字符串，提供连接数据库的必要信息
            conn.Open();//连接数据库

            if (conn.State.ToString() == "Open")//检测是否连接成功
            {
                //Console.WriteLine("连接MySQL数据库成功");
                MySqlCommand cmd = new MySqlCommand(cmd_select_get, conn);
                MySqlDataReader dr;//如果想要使用查询语句，则应先创建MySqlDataReader类，此为ExecuteReader()方法的返回类型
                dr = cmd.ExecuteReader();//使用ExecuteReader()方法执行查询语句
                while (dr.Read())//使用Read()方法查询返回的MySqlDataReader对象中的数据，返回值为true或false
                {
                    //Console.WriteLine(dr["id"] + " " + dr["date"] + " " + dr["time"] + " " + dr["realtime_elec"] + " " + dr["delta_elec"]);//输出查询到的数据，dr["字段名"]，这里的字段名对应数据库查询的表中的字段名
                    f = (decimal)dr["realtime_elec"];
                    Console.WriteLine("当前数据表最新一条realtime_elec为：{0}", f);
                
                }
                dr.Close();
            }
            else
            {
                Console.WriteLine("获取历史数据失败");
            }
            conn.Close();
            return f;

        }

        //读取数据表当前记录（也就是最新的记录）的id
        public static int GetId(string tablename)
        {
            int id = 0;
            string cmd_select_getid = "select*from " + tablename + " ORDER by id desc limit 0,1";
           

            MySqlConnection conn = null;//创建MySqlConnection类
            conn = new MySqlConnection("Server=localhost;Database=elec_monitor;Username=root;Password=");//创建连接字符串，提供连接数据库的必要信息
            conn.Open();//连接数据库

            if (conn.State.ToString() == "Open")//检测是否连接成功
            {
                //Console.WriteLine("连接MySQL数据库成功");
                MySqlCommand cmd = new MySqlCommand(cmd_select_getid, conn);
                MySqlDataReader dr;//如果想要使用查询语句，则应先创建MySqlDataReader类，此为ExecuteReader()方法的返回类型
                dr = cmd.ExecuteReader();//使用ExecuteReader()方法执行查询语句
                while (dr.Read())//使用Read()方法查询返回的MySqlDataReader对象中的数据，返回值为true或false
                {
                    //Console.WriteLine(dr["id"] + " " + dr["date"] + " " + dr["time"] + " " + dr["realtime_elec"] + " " + dr["delta_elec"]);//输出查询到的数据，dr["字段名"]，这里的字段名对应数据库查询的表中的字段名
                    id = (int)dr["id"];

                }
                dr.Close();
            }
            else
            {
                Console.WriteLine("获取当前id失败");
            }
            conn.Close();
            return id;

        }
    }

}
