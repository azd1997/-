# -*- coding: utf-8 -*-
from __future__ import division, print_function
import skfuzzy as fuzz
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

import mode_cluster_score


def get_label(u_, data):   # u_[0]和data[0]等长
    lenth = len(data[0])
    width = len(u_)
    labels = []
    for a in range(0, lenth):
        list_inner = []
        for b in range(0, width):
            list_inner.append(u_[b][a])
        max_probability = max(list_inner)
        label = list_inner.index(max_probability)
        labels.append(label)
    return labels


def plot_scatter(X, labels=None, title="Scatter Plot"):
    labels = np.zeros(shape=X.shape[0], dtype=int) if labels is None else labels
    colors = ['b', 'orange', 'g', 'r', 'c', 'm', 'y', 'k', 'Brown', 'ForestGreen']
    col_dict = {}
    i = 0
    for lab in np.unique(labels):
        col_dict[lab] = colors[i]
        i += 1

    fig1 = plt.figure(1, figsize=(8, 6))
    ax = fig1.add_subplot(1, 1, 1)

    for i in np.unique(labels):
        indx = np.where(labels == i)[0]
        plt.scatter(X[indx, 0], X[indx, 1], color=col_dict[i], marker='o', s=100, alpha=0.5)

    plt.setp(ax.get_xticklabels(), rotation='horizontal', fontsize=16)
    plt.setp(ax.get_yticklabels(), rotation='vertical', fontsize=16)

    plt.xlabel('$x_1$', size=20)
    plt.ylabel('$x_2$', size=20)
    plt.title(title, size=20)

    plt.show()
    plt.close()


'''
    从data_for_cluster读取数据
'''

alldata = np.loadtxt(open(".\data_for_cluster_gaus11.csv", "rb"), delimiter=",", skiprows=0)
# print(alldata)

'''
    PCA降维
'''
'''
# 要进行pca降维，首先要将数据转为24维数据。
data_for_pca = []
length0 = len(alldata[0])
for x in range(0, length0):
    data_for_pca_inner = []
    for y in range(0, 23):
        data_for_pca_inner.append(alldata[y][x])
    data_for_pca.append(data_for_pca_inner)
# print(data_for_pca)
'''
# pca降维
pca_obj = PCA(n_components=2)
pca_obj.fit(alldata)
newdata = pca_obj.transform(alldata)
# print(newdata)

# 再把数组给转置回来
data_for_cluster = []
data_for_cluster0 = []
data_for_cluster1 = []
for each in newdata:
    data_for_cluster0.append(each[0])
    data_for_cluster1.append(each[1])
data_for_cluster.append(data_for_cluster0)
data_for_cluster.append(data_for_cluster1)
# print(data_for_cluster)
data_array = np.array(data_for_cluster)
print(data_array)
data_final = np.vstack(data_array)
print(data_final)

'''
    FCM聚类
'''

# 聚类范围
k = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
test = [4]
# 分类一致性系数
fpcs = []

for i in test:
    data1 = alldata.transpose()

    cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(data1, i, 2, error=0.005, maxiter=1000)
    np.savetxt('fcm.csv', cntr, delimiter=',')
    fpcs.append(fpc)
    print("*********************************")
    for pt in cntr:
        print(pt)
    print("*********************************")
    # 利用概率矩阵u,对data进行标签
    #my_label = get_label(u, data_final)
    # 将data_final转置
    #my_data = np.transpose(data_final)
    # 利用data_final、cntr、my_label、i进行评分计算
    #my_score = mode_cluster_score.score(my_data, cntr, my_label, i, 2)
    #print('得分为')
    #print(my_score)

    # 数据可视化
    #plot_scatter(my_data, my_label, title='FCM')

print("*********************************")
print(fpcs)


'''
    各簇中心（即各模型）绘图、fpc绘图
'''
'''
    选择k=5重新聚类
'''
'''
cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(alldata, 5, 2, error=0.005, maxiter=1000)

i = 0
for pt in cntr:
    print(pt)
    fig = plt.figure(figsize=(100, 100))
    plt.plot(pt, linestyle='-', linewidth=6, color='r', marker='*', markersize=6)
    fig_name = 'fig%s.png' % i
    plt.savefig(fig_name)
    plt.close()
    i = i + 1
'''


