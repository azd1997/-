from __future__ import division, print_function
import numpy as np
import skfuzzy as fuzz
import types

centers = [[4, 2, 100, 300, 70, 50, 40, 20, 30, 50, 90, 70, 50, 70, 20, 40, 50, 30, 70, 90, 50, 30, 70, 90],
           [1, 7, 200, 200, 60, 60, 30, 30, 40, 40, 80, 80, 50, 70, 20, 40, 50, 30, 70, 90, 50, 30, 70, 90],
           [5, 6, 300, 100, 50, 70, 20, 40, 50, 30, 70, 90, 50, 70, 20, 40, 50, 30, 70, 90, 50, 30, 70, 90]]
sigmas = [[0.8, 0.3, 0.1, 0.8, 0.3, 0.1, 0.8, 0.3, 0.1, 0.8, 0.3, 0.1, 0.8,0.3,0.1,0.8,0.3,0.1,0.8,0.3,0.1,0.8,0.3,0.1],
              [0.3, 0.5, 0.2, 0.8, 0.3, 0.1, 0.8, 0.3, 0.1, 0.8, 0.3, 0.1, 0.8,0.3,0.1,0.8,0.3,0.1,0.8,0.3,0.1,0.8,0.3,0.1],
              [1.1, 0.7, 0.9, 0.8, 0.3, 0.1, 0.8, 0.3, 0.1, 0.8, 0.3, 0.1, 0.8,0.3,0.1,0.8,0.3,0.1,0.8,0.3,0.1,0.8,0.3,0.1]]
# Generate test data
np.random.seed(42)  # Set seed for reproducibility

apts = np.zeros(1)
bpts = np.zeros(1)
cpts = np.zeros(1)
dpts = np.zeros(1)
epts = np.zeros(1)
fpts = np.zeros(1)
gpts = np.zeros(1)
hpts = np.zeros(1)
ipts = np.zeros(1)
jpts = np.zeros(1)
kpts = np.zeros(1)
lpts = np.zeros(1)
mpts = np.zeros(1)
npts = np.zeros(1)
opts = np.zeros(1)
ppts = np.zeros(1)
qpts = np.zeros(1)
rpts = np.zeros(1)
spts = np.zeros(1)
tpts = np.zeros(1)
upts = np.zeros(1)
vpts = np.zeros(1)
wpts = np.zeros(1)
xpts = np.zeros(1)






labels = np.zeros(1)

print("*********************")
for i, ((amu, bmu, cmu, dmu, emu, fmu,gmu, hmu, imu,jmu, kmu, lmu,mmu, nmu, omu, pmu, qmu, rmu,smu, tmu, umu,vmu, wmu, xmu), (asigma, bsigma, csigma, dsigma, esigma, fsigma,gsigma, hsigma, isigma,jsigma, ksigma, lsigma,msigma, nsigma, osigma, psigma, qsigma, rsigma,ssigma, tsigma, usigma,vsigma, wsigma, xsigma)) in enumerate(zip(centers, sigmas)):
    apts = np.hstack((apts, np.random.standard_normal(200) * asigma + amu))
    bpts = np.hstack((bpts, np.random.standard_normal(200) * bsigma + bmu))
    cpts = np.hstack((cpts, np.random.standard_normal(200) * csigma + cmu))
    dpts = np.hstack((dpts, np.random.standard_normal(200) * dsigma + dmu))
    epts = np.hstack((epts, np.random.standard_normal(200) * esigma + emu))
    fpts = np.hstack((fpts, np.random.standard_normal(200) * fsigma + fmu))
    gpts = np.hstack((gpts, np.random.standard_normal(200) * gsigma + gmu))
    hpts = np.hstack((hpts, np.random.standard_normal(200) * hsigma + hmu))
    ipts = np.hstack((ipts, np.random.standard_normal(200) * isigma + imu))
    jpts = np.hstack((jpts, np.random.standard_normal(200) * jsigma + jmu))
    kpts = np.hstack((kpts, np.random.standard_normal(200) * ksigma + kmu))
    lpts = np.hstack((lpts, np.random.standard_normal(200) * lsigma + lmu))
    mpts = np.hstack((mpts, np.random.standard_normal(200) * msigma + mmu))
    npts = np.hstack((npts, np.random.standard_normal(200) * nsigma + nmu))
    opts = np.hstack((opts, np.random.standard_normal(200) * osigma + omu))
    ppts = np.hstack((ppts, np.random.standard_normal(200) * psigma + pmu))
    qpts = np.hstack((qpts, np.random.standard_normal(200) * qsigma + qmu))
    rpts = np.hstack((rpts, np.random.standard_normal(200) * rsigma + rmu))
    spts = np.hstack((spts, np.random.standard_normal(200) * ssigma + smu))
    tpts = np.hstack((tpts, np.random.standard_normal(200) * tsigma + tmu))
    upts = np.hstack((upts, np.random.standard_normal(200) * usigma + umu))
    vpts = np.hstack((vpts, np.random.standard_normal(200) * vsigma + vmu))
    wpts = np.hstack((wpts, np.random.standard_normal(200) * wsigma + wmu))
    xpts = np.hstack((xpts, np.random.standard_normal(200) * xsigma + xmu))

    labels = np.hstack((labels, np.ones(200) * i))
print(apts)
print(type(apts[11]))
alldata = np.vstack((apts, bpts, cpts,dpts, epts, fpts,gpts, hpts, ipts,jpts, kpts, lpts,mpts, npts, opts,ppts, qpts, rpts,spts, tpts, upts,vpts, wpts, xpts))
print(alldata)
cntr, u_orig, _, _, _, _, _ = fuzz.cluster.cmeans(alldata, 3, 2, error=0.005, maxiter=1000)

print("*********************")
for pt in cntr:
    print(pt)
print("*********************")