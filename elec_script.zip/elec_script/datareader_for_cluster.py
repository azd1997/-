# -*- coding: utf-8 -*-
from __future__ import division, print_function
import numpy as np
import pymysql


'''
    连接数据库，获取所有日用电数据
'''
# 连接数据库
db = pymysql.connect(host="localhost", user="root", password="", db="elec_monitor", port=3306)
cur = db.cursor()
# 获取所有用电数据，包括无用能模式。
num_list = np.linspace(1, 366, 366)
room_list = np.linspace(1, 79, 79)
hour_list = np.linspace(0, 23, 24)
data_list0 = []
hour_data = []


for x in hour_list:
    hour = int(x)
    #print(hour)
    data_list1 = []

    for y in room_list:
        room_name = str(int(y)) + 'a'
        data_list2 = []
        sql = "select %s from room_data2016 where hour=%s " % (room_name, hour)
        try:
            cur.execute(sql)  # 执行sql语句
            results = cur.fetchall()  # 获取查询的所有记录
            # 遍历结果
            for row in results:
                data = float(row[0])     # cmeans指支持float、int, 不支持decimal
                data_list2.append(data)
        except Exception as e:
            raise e
        #print(data_list2)
        #print(len(data_list2))
        data_list1.extend(data_list2)

    #print(data_list1)
    #print(len(data_list1))
    #hour_data[hour] = data_list1
    hour_data.append(data_list1)
# print(hour_data)


# 剔除无用能模式数据，即24小时用电量为0的数据
data_length = len(hour_data[0])
print(data_length)
length_list = np.linspace(0, data_length-1, data_length)
to_be_deleted = []

for z in length_list:
    zint = int(z)
    elec24 = 0
    for w in hour_list:
        wint = int(w)
        elec24 += hour_data[wint][zint]
    # print(elec24)
    if elec24 == 0:
        to_be_deleted.append(zint)
# print(to_be_deleted)
# 根据to_be_deleted列表，删除hour_data中的无用能数据
m = 0
for d in to_be_deleted:
    index = d - m
    for w in hour_list:
        wint = int(w)
        # hour_data[wint].pop(index)
        del hour_data[wint][index]
    m = m + 1      # 考虑到每删除一个前面的元素后待删元素的索引减1

# 用作检验
data_length2 = len(hour_data[0])
print(data_length2)
length_list2 = np.linspace(0, data_length2-1, data_length2)

for z in length_list2:
    zint = int(z)
    elec24 = 0
    for w in hour_list:
        wint = int(w)
        elec24 += hour_data[wint][zint]
    print(elec24)
    if elec24 == 0:
        print('数据剔除不正确')
print('数据剔除完成无误')

hour_data_array = np.array(hour_data)
alldata = np.vstack(hour_data_array)
# print(alldata)

# 存入csv
np.savetxt('data_for_cluster.csv', alldata, delimiter=',')
