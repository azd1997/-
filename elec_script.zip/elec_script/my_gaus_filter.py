# -*- coding: utf-8 -*-
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from math import e

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来显示中文字体
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示正负号
# 中文内容前需加u。  例如   u'中文'


# !!!!!!!!!!!!!!!!!!!!!     range(0,10)=[0,1,2,3,...,9]

'''
    创建二维数组
'''


def list_2d(i, j):  # i为二维数组外层元素数，即内部含有i个数组[0,0,0,...,0]
    list2d = []
    for a in range(0, i):
        list1d_array = np.linspace(0, 0, j)
        list1d = list1d_array.tolist()
        list2d.append(list1d)
    return list2d


'''
    D2矩阵补位形成D3数组的列表形式d3
'''


def d2_to_d3(data, w, m_col):
    # 首先要把D2数组转回列表，方便修改
    d2 = data.tolist()

    w_down = int(w/2)
    d3 = []
    for i in range(0, n):
        d3_inner = []
        for j in range(0, w_down):
            d3_inner.append(d2[i][m_col-j-1])
        # print(d3_inner)
        for k in range(0, m_col):
            d3_inner.append(d2[i][k])
        # print(d3_inner)
        for l in range(0, w_down):
            d3_inner.append(d2[i][l])
        # print(d3_inner)
        d3.append(d3_inner)
    # print(d3)
    return d3


'''
    d3矩阵与k系数矩阵卷积
'''


def d3_to_d4(data, k_list, n_row):
    d4 = []
    for i in range(0, n_row):
        d4_inner = np.convolve(data[i], k_list, mode='full')
        d4.append(d4_inner)
    # print(d4[0])
    return d4


'''    
    # 长度为m的数列与长度为n的数列进行卷积，其卷积数列长度为m+n-1
    # m !== n时，应将短的那一个用0补至一样长
    col_num = m_col + 2 * int(w / 2) + w - 1  # 新矩阵列数
    col_num_2 = 2*(m_col + 2*int(w/2)) - 1   # 将系数矩阵补至与d3同列
    col_num_data = len(data[0])
    # print(col_num_2)
    # print(col_num_data)
    zero_list = []
    for a in range(0, col_num_data-len(k_list)):
        zero = 0
        zero_list.append(zero)
    k_list.extend(zero_list)

    d4_list2 = []
    for i in range(0, n_row):  # d4行索引
        d4_list1 = []
        for p in range(0, col_num_2):  # d4列索引
            sum_inner = 0  # 定义一个中转变量
            if p <= col_num_data:
                for j in range(0, p):
                    sum_inner += data[i][j] * k_list[p-j+1]
            else:
                for j in range(p, col_num_2+1):
                    sum_inner += data[i][j-col_num_data] * k_list[p-j+col_num_data-1]
            d4_list1.append(sum_inner)
        del d4_list1[col_num:]      # 将d2_list1  col_num以后的删掉（都是0）
        d4_list2.append(d4_list1)
    d4 = d4_list2
    return d4
'''

'''
    高斯核函数
'''


def gauss(x, sigma):
    mi = -(x*x/(2*sigma))
    return e**mi


'''
    获取窗宽矩阵和系数矩阵
'''


def get_x_k(sigma, w):  # 窗宽w
    x_list = []
    k_list = []  # 系数矩阵
    gauss_xj_sigma_sum = 0
    for a in range(1, w+1):
        xi = -(w - 1)/2 + a - 1
        x_list.append(xi)
        gauss_xj_sigma_sum += gauss(xi, sigma)
    # print(x_list)  # 现在得到了x_list
    for b in range(1, w+1):
        xi = -(w - 1)/2 + a - 1
        ki = gauss(xi, sigma) / gauss_xj_sigma_sum
        k_list.append(ki)
    # print(k_list)  # 现在得到了k_list
    return x_list, k_list


'''
    从d4中间取n*m矩阵，即d5
'''


def d4_to_d5(data, w):
    d5 = []
    for i in range(0, n):
        d5_inner = []
        for j in range(0, m):
            d5_inner.append(data[i][j+w-1])
        d5.append(d5_inner)
    # print(d5[0])
    return d5


'''
    未高斯平滑处理与高斯平滑处理对比
'''


def fig_compare(data1, data2, start_day, end_day):
    data_list_1 = []
    data_list_2 = []
    for a in range(start_day-1, end_day):
        data_list_1.append(data1[a])
        data_list_2.append(data2[a])

    length = len(data_list_1)
    data_fig_1 = []
    data_fig_2 = []
    for j in range(0, 24):
        data_sum1 = 0
        data_sum2 = 0
        for i in range(0, length):
            data_sum1 += data_list_1[i][j]
            data_sum2 += data_list_2[i][j]
        data_average1 = data_sum1 / length
        data_average2 = data_sum2 / length
        data_fig_1.append(data_average1)
        data_fig_2.append(data_average2)

    x = range(0, 24)
    plt.figure(figsize=(8, 4))
    plt.plot(x, data_fig_1, label=u"未处理", color="b", linewidth=2)
    plt.plot(x, data_fig_2, label=u"平滑处理", color="r", linewidth=2)
    plt.xlabel(u"时刻（h）")
    plt.ylabel(u"用电量（kW·h）")
    plt.title(u"高斯平滑处理前后对比")
    plt.legend()
    plt.show()
    plt.close()


'''
    从data_for_cluster读取数据,并开始主程序
'''


def data_normalize(data):
    length = len(data)
    d6 = []
    for i in range(0, length):
        di_sum = 0
        d6_inner = []
        for j in range(0, 24):
            di_sum += data[i][j]
        for j in range(0, 24):
            d6_inner.append(data[i][j] / di_sum)
        d6.append(d6_inner)
    # print(data[3])
    # print(d6[3])
    return d6


'''
    从data_for_cluster读取数据,并开始主程序
'''

alldata = np.loadtxt(open(".\data_my_nolabel.csv", "rb"), delimiter=",", skiprows=0)
D1 = alldata
D2 = np.transpose(D1)  # D2为D1的转置矩阵，其行为24小时数据
# 针对24列数据（原始）
n = len(D2[0])  # n为对象个数，也即D2矩阵行数
m = len(D1[0])  # m为维数，也即D2矩阵列数


# 针对24行数据（原始）
# n = len(D1[0])  # n为对象个数，也即D2矩阵行数
# m = len(D2[0])  # m为维数，也即D2矩阵列数
# print(D1[0])
# print('********************************')
# print(len(D2[0]))

Sigma = 60
W = 3  # w<=5且只能为单数

# 求取D3矩阵，D3为list，针对D1为24列数据
D3 = d2_to_d3(D1, W, m)
# 求取D3矩阵，D3为list，针对D1为24行数据
# D3 = d2_to_d3(D2, W, m)
# print(len(D3[0]))
# print(D2[0])
# print(D3[0])
xlist, klist = get_x_k(Sigma, W)
D4 = d3_to_d4(D3, klist, n)
D5 = d4_to_d5(D4, W)

# 对D5进行标准化
D6 = data_normalize(D5)
# print(len(D5))
# print((len(D6)))
np.savetxt('data_for_cluster_gaus11.csv', D6, delimiter=',')

# 未免高斯滤波效果不佳，将D1直接标准化得D7并存储
D7 = data_normalize(D1)
np.savetxt('data_for_cluster_gaus22.csv', D6, delimiter=',')

fig_compare(D1, D5, 3300, 3310)


'''
    定义总调用函数
'''
def gaus_normal(data, sigma, w)   # data为输入的24维数据，sigma=60，W=3
    n_row = 1  # 因为是单房间单天数据，所以只是一条数据，且为一维数组，所以n直接赋值为1
    m_col = len(data)
    D3_ = d2_to_d3(data, w, m_col)
    xlist_, klist_ = get_x_k(sigma, w)
    D4_ = d3_to_d4(D3_, klist_, n_row)
    D5_ = d4_to_d5(D4_, w)
    D6_ = data_normalize(D5_)
    return D6_













