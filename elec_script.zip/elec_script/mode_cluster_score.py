# -*- coding: utf-8 -*-
from __future__ import division, print_function
import skfuzzy as fuzz
import pyclust

'''
    欧氏距离计算
'''


def eu_dist(point1, point2):   # point1,point2是两个等长列表
    length = len(point1)
    dist_square = 0
    for i in range(0,length):
        delta = point1[i] - point2[i]
        delta_square = delta**2
        dist_square += delta_square

    dist = dist_square**0.5
    return dist


'''                              测试eudist（）是否正确
point1_ = list(range(0, 24))
point2_ = list(range(1, 25))
Eu_Dist = eu_dist(point1_, point2_)
print(Eu_Dist)
'''

'''
    获取各类簇集合
'''


def get_clusters(data, label, ncluster):  #data指最终用来聚类的数据列表（n*2的二维列表，不降维的话运算量较大）；label指最终得到的标签列表（n*1); ncluster指聚类数
    length = len(data)  # 得到n值。data和label是等长的
    all_clusters = []
    for a in range(0, ncluster):
        list_inner = []
        all_clusters.append(list_inner)    # all_clusters是一个三维数组
    for b in range(0, ncluster):
        for i in range(0, length):
            if label[i] == b:
                all_clusters[b].append(data[i])
    return all_clusters


'''
    获取ncluster = 1时的center
'''


def get_center(data, method, ncluster):  # 返回中心点数组
    # 通过method选择聚类方式计算data中心点
    center = []
    if method == 0:
        km = pyclust.KMeans(n_clusters=ncluster, n_trials=10)
        km.fit(data)
        center = km.centers_
    elif method == 1:
        kmd = pyclust.KMedoids(n_clusters=ncluster, n_trials=10)
        kmd.fit_predict(data)
        center = kmd.centers_
    elif method == 2:
        cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(data, ncluster, 2, error=0.005, maxiter=1000)
        center = cntr

    return center


'''
    聚类平均半径
'''


def cluster_average_radio(data, center, label, ncluster):   # 参数必须等于或多于get_clusters(); center是聚类结果中心点列表
    clusters = get_clusters(data, label, ncluster)   # clusters[]为三维数组，长度为ncluster
    # 获取各簇长度
    len_of_clusters = []
    for i in range(0, ncluster):
        length_inner = len(clusters[i])
        len_of_clusters.append(length_inner)

    # 正式计算
    r_sum = 0
    for j in range(0, ncluster):
        dist_list = []
        for x in range(0, len_of_clusters[j]):
            eu_Dist = eu_dist(clusters[j][x], center[j])     # 这要求聚类之前必须将数据降维至二维，因为clusters[j][x]长度为2
            # 到上面这步，是通过循环，计算了clusters[j]全部数据中各点与其所在簇中心点的欧氏距离
            dist_list.append(eu_Dist)
        r_sum += max(dist_list)
    r_average = r_sum / ncluster
    return r_average


'''
    r_1
'''


def cluster_average_radio_r1(data, method):
    # 获取center
    centers = get_center(data, method, 1)
    center = centers[0]
    # 利用data和得到的中心点center计算r_1
    dist_list = []
    for x in range(0, len(data)):
        eu_Dist = eu_dist(data[x], center)  # 这要求聚类之前必须将数据降维至二维
        # 到上面这步，是通过循环，计算了clusters[j]全部数据中各点与其所在簇中心点的欧氏距离
        dist_list.append(eu_Dist)
    r_1 = max(dist_list)

    return r_1


'''
    聚类平均直径
'''


def cluster_average_diameter(data, label, ncluster):
    clusters = get_clusters(data, label, ncluster)  # clusters[]为三维数组，长度为ncluster
    # 获取各簇长度
    len_of_clusters = []
    for i in range(0, ncluster):
        length_inner = len(clusters[i])
        len_of_clusters.append(length_inner)

    # 正式计算
    d_sum = 0
    for j in range(0, ncluster):
        dist_list = []
        for x in range(0, len_of_clusters[j]-1):
            for y in range(x+1, len_of_clusters[j]):
                eu_Dist = eu_dist(clusters[j][x], clusters[j][y])  # 这要求聚类之前必须将数据降维至二维，因为clusters[j][x]长度为2
                # 到上面这步，是通过循环，计算了clusters[j]全部数据中各点与其所在簇中心点的欧氏距离
                dist_list.append(eu_Dist)
        d_sum += max(dist_list)
    d_average = d_sum / ncluster
    return d_average


'''
    d_1
'''


def cluster_average_diameter_d1(data):
    len_data = len(data)
    dist_list = []
    for x in range(0, len_data-1):
        dist_list_inner = []
        for y in range(x+1, len_data):
            eu_Dist = eu_dist(data[x], data[y])  # 这要求聚类之前必须将数据降维至二维
            # 到上面这步，是通过循环，计算了clusters[j]全部数据中各点与其所在簇中心点的欧氏距离
            dist_list_inner.append(eu_Dist)
        dist_list.extend(dist_list_inner)
    d_1 = max(dist_list)

    return d_1


'''
    聚类平均最小间距
'''


def cluster_average_min_dist(data, label, ncluster):
    clusters = get_clusters(data, label, ncluster)  # clusters[]为三维数组，长度为ncluster
    # 获取各簇长度
    len_of_clusters = []
    for i in range(0, ncluster):
        length_inner = len(clusters[i])
        len_of_clusters.append(length_inner)

    # 获取clusters除clusters[p]以外的数据，并合并到二维列表clusters_other[p]中
    clusters_other = []
    for p in range(0, ncluster):
        list_in = []
        for q in range(0, ncluster):
            if q != p:
                list_in.extend(clusters[q])
        clusters_other.append(list_in)

    # 正式计算
    b_sum = 0
    for j in range(0, ncluster):
        dist_list = []
        for x in range(0, len_of_clusters[j]):
            dist_list_inner = []
            for y in range(0, len(clusters_other[j])):
                eu_Dist = eu_dist(clusters[j][x], clusters_other[j][y])  # 这要求聚类之前必须将数据降维至二维，因为clusters[j][x]长度为2
                # 到上面这步，是通过循环，计算了clusters[j]全部数据中各点与其所在簇中心点的欧氏距离
                dist_list_inner.append(eu_Dist)
            dist_list.extend(dist_list_inner)
        b_sum += min(dist_list)
    b_average = b_sum / ncluster

    return b_average


'''
    b_n
'''


def cluster_average_min_dist_bn(data):
    len_data = len(data)
    # 获取clusters除clusters[p]以外的数据，并合并到二维列表clusters_other[p]中
    clusters_other = []
    for q in range(0, len_data):
        list_inner = data.tolist()
        del list_inner[q]
        clusters_other.append(list_inner)
    print(len(clusters_other[0]))
    print('************')

    b_sum = 0
    for x in range(0, len_data):
        dist_list = []
        for y in range(0, len_data-1):
            eu_Dist = eu_dist(data[x], clusters_other[x][y])
            dist_list.append(eu_Dist)
        b_sum += min(dist_list)
    b_n = b_sum / len_data

    print('qqqqqqqqqqqqqq')

    return b_n


'''
    评分公式
'''


def score(data, center, label, ncluster, method):   # ncluster>1。
    # _k的参数应该来自聚类结果，其他来自直接data参数计算;;;method=[0,1,2],0表示使用kmeans,1表示kmedoid,2表示fcm

    r_k = cluster_average_radio(data, center, label, ncluster)
    print('聚类平均半径为：')
    print(r_k)
    # r_1 = cluster_average_radio_r1(data, method)
    # print('r_1为：')
    # print(r_1)
    d_k = cluster_average_diameter(data, label, ncluster)
    print('聚类平均直径为：')
    print(d_k)
    # d_1 = cluster_average_diameter_d1(data)
    # print('d_1为：')
    # print(d_1)
    b_k = cluster_average_min_dist(data, label, ncluster)
    print('聚类平均最小间距为：')
    print(b_k)
    # b_n = cluster_average_min_dist_bn(data)
    # print('b_n为：')
    # print(b_n)

    # my_score = (b_k * r_1 * d_1) / (b_n * r_k * d_k)
    my_score = (b_k * r_k * d_k) / (0.00294 * 0.43064 * 0.76989)

    return my_score