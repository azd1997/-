# -*- coding: utf-8 -*-
from __future__ import division, print_function
import pyclust
import numpy as np
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

import mode_cluster_score

'''
    定义绘图函数
'''


def plot_scatter(X, labels=None, title="Scatter Plot"):
    labels = np.zeros(shape=X.shape[0], dtype=int) if labels is None else labels
    colors = ['b', 'orange', 'g', 'r', 'c', 'm', 'y', 'k', 'Brown', 'ForestGreen']
    col_dict = {}
    i = 0
    for lab in np.unique(labels):
        col_dict[lab] = colors[i]
        i += 1

    fig1 = plt.figure(1, figsize=(8, 6))
    ax = fig1.add_subplot(1, 1, 1)

    for i in np.unique(labels):
        indx = np.where(labels == i)[0]
        plt.scatter(X[indx, 0], X[indx, 1], color=col_dict[i], marker='o', s=100, alpha=0.5)

    plt.setp(ax.get_xticklabels(), rotation='horizontal', fontsize=16)
    plt.setp(ax.get_yticklabels(), rotation='vertical', fontsize=16)

    plt.xlabel('$x_1$', size=20)
    plt.ylabel('$x_2$', size=20)
    plt.title(title, size=20)

    plt.show()
    plt.close()


'''
    从data_for_cluster读取数据
'''

alldata = np.loadtxt(open(".\data_for_cluster_gaus11.csv", "rb"), delimiter=",", skiprows=0)
# print(alldata)

'''
    不降维的数据整理
'''
'''
# 要将数据转为24维数据。
data_for_km = []
length0 = len(alldata[0])
for x in range(0, length0):
    data_for_km_inner = []
    for y in range(0, 23):
        data_for_km_inner.append(alldata[y][x])
    data_for_km.append(data_for_km_inner)
# print(data_for_km)
data_array = np.array(data_for_km)
data_final = np.vstack(data_array)
print(data_final)
'''
'''
    PCA降维处理，与前者不能同时使用
'''
'''                                       使用data_for_cluster需要进行下面的转换，使用gaus版本不需要
# 要进行pca降维，首先要将数据转为24维数据。
data_for_pca = []
length0 = len(alldata[0])
for x in range(0, length0):
    data_for_pca_inner = []
    for y in range(0, 23):
        data_for_pca_inner.append(alldata[y][x])
    data_for_pca.append(data_for_pca_inner)
# print(data_for_pca)
'''
data_for_pca = alldata
# pca降维
pca_obj = PCA(n_components=2)
pca_obj.fit(data_for_pca)
newdata = pca_obj.transform(data_for_pca)
print(len(newdata))

data_array = np.array(newdata)
data_final = np.vstack(data_array)

alldata1 = np.loadtxt(open(".\data_for_cluster.csv", "rb"), delimiter=",", skiprows=0)
alldata2 = alldata1.transpose()

'''
    K-means
'''

km = pyclust.KMeans(n_clusters=5, n_trials=10)
#km.fit(data_final)

km.fit(alldata)
np.savetxt('km1.csv', km.centers_, delimiter=',')

km.fit_predict(alldata2)
np.savetxt('km2.csv', km.centers_, delimiter=',')
# myscore = mode_cluster_score.score(data_final, km.centers_, km.labels_, 15, 0)
# print(myscore)


print('******')
#print(km.centers_)
print('!!!!!!!!')
#print(km.labels_)
#print(km.labels_[11])
#plot_scatter(data_final, labels=km.labels_, title="k-means")
#np.savetxt('log.csv', km.labels_, delimiter=',')

