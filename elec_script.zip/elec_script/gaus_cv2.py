import os
os.chdir('./')  # 切换地址到存放灰度图的地址
import GaussianBlur