import pymysql
import numpy

db = pymysql.connect(host="localhost", user="root", password="", db="elec_monitor", port=3306)
cur = db.cursor()

typeid_list = numpy.linspace(1, 14, 14)
modelist = [1, 2, 3, 4]  #把无用能模式（5）剔除，避免无意义的逻辑处理

for x in typeid_list:
    for mode in modelist:
        mode_low = str(mode) + 'low'
        mode_high = str(mode) + 'high'
        typeid = int(x)
        data_list = []
        dateid_list = []
        sql1 = "select id from room_info where type=%s " % typeid
        try:
            cur.execute(sql1)
            result1 = cur.fetchall()
            for row1 in result1:
                roomid = row1[0]
                roomname = str(roomid) + 'a'
                roomname2 = 'cell' + str(roomid)

                #获取房间类型的其中一个房间的id和用电模式都符合的天数id。即（roomid,mode)=>dateid
                sql2 = "select id from roommode_all where %s=%s " % (roomname2, mode)
                try:
                    cur.execute(sql2)  # 执行sql语句
                    result2 = cur.fetchall()  # 获取查询的所有记录
                    for row2 in result2:
                        dateid = row2[0]
                        dateid_list.append(dateid)
                except Exception as e:
                    raise e

                #获取一个roomid下符合某中用电模式的dateid所对应的用电数据
                data_inner_list = []
                for y in dateid_list:
                    y_num = int(y)
                    sql3 = "select %s from room_data2016 where date_id=%s " % (roomname, y_num)
                    data_sum = 0
                    try:
                        cur.execute(sql3)  # 执行sql语句
                        result3 = cur.fetchall()  # 获取查询的所有记录
                        for row3 in result3:
                            data = row3[0]
                            data_sum += data   #data_sum就是一天的耗电量
                    except Exception as e:
                        raise e
                    if data_sum > 0:
                        data_inner_list.append(data_sum) #将一个房间的日电耗放入一个列表
                data_list.extend(data_inner_list)   #将多个房间的数据合并
        except Exception as e:
            raise e

        print(data_list)

        data_list.sort()  # 对列表按大小排序，sort()改变原列表，sorted()新建一列表
        data_list_length = len(data_list)  # 获取列表长度

        print(data_list)
        print(data_list_length)

        #求取四分法低能耗水平线和高能耗水平线并存储
        if data_list_length >= 4:
            index_1_4 = round(data_list_length / 4 - 1)  # 对列表1/4处元素索引四舍五入取整
            index_3_4 = round(3 * data_list_length / 4 - 1)
            low = data_list[index_1_4]
            high = data_list[index_3_4]

            print(index_1_4)
            print(index_3_4)

            sql4 = "UPDATE roomlevel_14 SET %s=%s,%s=%s WHERE type_id=%s" % (mode_low, low, mode_high, high, int(x))
            print(sql4)
            try:
                cur.execute(sql4)  # 执行sql语句
                db.commit()
            except Exception as e:
                raise e
        else:
            break

db.close
