import mode_cluster_score
import my_gaus_filter
import pymysql
import time
import numpy as np

'''
    此处的模式分类指昨日数据模式分类
'''
db = pymysql.connect(host="localhost", user="root", password="", db="elec_monitor", port=3306)
cur = db.cursor()

# 获取前一天日期
today_timestamp = time.time()
yesterday_timestamp = today_timestamp - 86400  # 天为86400秒
yesterday_local = time.localtime(yesterday_timestamp)   # 时间戳转为本地时间
yesterday = time.strftime('%Y-%m-%d', yesterday_local)   # 输出为1999-01-01形式

#创建房间列表。现在填了80、81两个房间，通过修改该列表可进行房间的增改
room_list = list(range(80, 82))

for x in room_list:
    room_name = str(int(x)) + 'a'
    room_name2 = 'cell'+str(int(x))
    sql = "select %s from room_data2018 where date=%s " % (room_name, yesterday)
    data_list = []
    data_sum = 0
    mode = -1   # -1作为初始值，随便取的
    try:
        cur.execute(sql)  # 执行sql语句
        results = cur.fetchall()  # 获取查询的所有记录
        # 遍历结果
        for row in results:
            data = row[0]
            data_list.append(data)
            # 由于用电数据不可能为负值，所以这里采用data_sum=data之和，通过判断sum是否为0来判断是否是无用能模式。
            data_sum += data
            # print(data)
    except Exception as e:
        raise e
    if data_sum == 0:
        mode = 5
    else:
        # 将用电数据滤波并标准化
        yesterday_data = my_gaus_filter.gaus_normal(data_list, 60, 3)
        # 读取kmeans,k=5聚类模型
        centers = np.loadtxt(open(".\km1.csv", "rb"), delimiter=",", skiprows=0)

        dist_list = []
        for i in range(0, 5):
            dist = mode_cluster_score.eu_dist(yesterday_data, centers[i])
            dist_list.append(dist)
        min_dist = min(dist_list)
        label = dist_list.index(min_dist)
        if label == 0 or label == 1:
            mode = 1
        else:
            mode = label
    print('识别为：' + str(mode))
    # 将结果存入roommode_all表
    sql2 = "UPDATE roommode_all SET %s=%s WHERE date=%s" % (room_name2, mode, yesterday)
    try:
        cur.execute(sql2)  # 执行sql语句
        db.commit()
    except Exception as e:
        raise e
db.close()  # 关闭连接

'''
data = []
centers = []
length = len(data)
labels = []
modes = []
for x in range(0, length):
    dist_list = []
    for i in range(0, 5):
        dist = mode_cluster_score.eu_dist(data[x], centers[i])
        dist_list.append(dist)
    min_dist = min(dist_list)
    label = dist_list.index(min_dist)
    if label == 0 or label == 1:
        mode = 0
    elif label == 2:
        mode = 1
    elif label == 3:
        mode = 2
    elif label == 4:
        mode = 3
    modes.append(mode)
'''
