'''
import numpy as np
alldata = np.loadtxt(open(".\data_my_nolabel.csv", "rb"), delimiter=",", skiprows=0)
print(len(alldata))
print(alldata[0])
'''
'''
import numpy as np
alldata = np.loadtxt(open(".\data_for_cluster_gaus11.csv", "rb"), delimiter=",", skiprows=0)
alllabel = np.loadtxt(open(".\log.csv", "rb"), delimiter=",", skiprows=0)

data = alldata.tolist()
label = alllabel.tolist()

ncluster = 4
length = len(data)  # 得到n值。data和label是等长的
all_clusters = []
for a in range(0, ncluster):
    list_inner = []
    all_clusters.append(list_inner)  # all_clusters是一个三维数组

for b in range(0, ncluster):
    for i in range(0, length):
        if label[i] == b:
            all_clusters[b].append(data[i])
print(label[0])
print('*****************')
print(len(all_clusters))
print(all_clusters[0])
length = len(all_clusters[0]) + len(all_clusters[1]) +len(all_clusters[2])+len(all_clusters[3])
print(length)
'''
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来显示中文字体
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示正负号
# 中文内容前需加u。  例如   u'中文'

'''
x = list(range(2, 16))
fpc = [0.76485, 0.70551, 0.59056, 0.5547, 0.52977, 0.523, 0.502, 0.482, 0.453, 0.443, 0.441, 0.416, 0.399, 0.421]
plt.figure(figsize=(8, 4))
plt.plot(x, fpc, color="b", linewidth=2)
plt.xlabel(u"聚类数")
plt.ylabel(u"fpc")
plt.title(u"fpc-ncluster曲线")
plt.legend()
plt.show()
plt.close()
'''
km = np.loadtxt(open(".\km.csv", "rb"), delimiter=",", skiprows=0)
kmd = np.loadtxt(open(".\kmd.csv", "rb"), delimiter=",", skiprows=0)
fcm = np.loadtxt(open(".\\fcm.csv", "rb"), delimiter=",", skiprows=0)
print(fcm)

x = list(range(0, 24))

plt.figure(figsize=(8, 4))
plt.plot(x, km[2], color="b", linewidth=2)
plt.xlabel(u"时刻（h）")
plt.ylabel(u"标准化用电量")
plt.title(u"km5_2")
plt.legend()
plt.show()
plt.close()