# -*- coding: utf-8 -*-
from __future__ import division, print_function
import pyclust
import treelib
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

import mode_cluster_score

'''
    定义绘图函数
'''


def plot_scatter(X, labels=None, title="Scatter Plot"):
    labels = np.zeros(shape=X.shape[0], dtype=int) if labels is None else labels
    colors = ['b', 'orange', 'g', 'r', 'c', 'm', 'y', 'k', 'Brown', 'ForestGreen', 'b', 'orange', 'g', 'r', 'c', 'b', 'orange', 'g', 'r', 'c']
    col_dict = {}
    i = 0
    for lab in np.unique(labels):
        col_dict[lab] = colors[i]
        i += 1

    fig1 = plt.figure(1, figsize=(8, 6))
    ax = fig1.add_subplot(1, 1, 1)

    for i in np.unique(labels):
        indx = np.where(labels == i)[0]
        plt.scatter(X[indx, 0], X[indx, 1], color=col_dict[i], marker='o', s=100, alpha=0.5)

    plt.setp(ax.get_xticklabels(), rotation='horizontal', fontsize=16)
    plt.setp(ax.get_yticklabels(), rotation='vertical', fontsize=16)

    plt.xlabel('$x_1$', size=20)
    plt.ylabel('$x_2$', size=20)
    plt.title(title, size=20)

    plt.show()
    plt.close()


'''
    从data_for_cluster读取数据
'''

alldata = np.loadtxt(open(".\data_for_cluster_gaus11.csv", "rb"), delimiter=",", skiprows=0)
# print(alldata)

'''
    降维
'''
data_for_pca = alldata
# pca降维
pca_obj = PCA(n_components=2)
pca_obj.fit(data_for_pca)
newdata = pca_obj.transform(data_for_pca)
print(len(newdata))

data_array = np.array(newdata)
data_final = np.vstack(data_array)


'''
    K-medoids聚类
'''

# for i in range(2, 9):
kmd = pyclust.KMedoids(n_clusters=5, n_trials=10)
#kmd.fit(data_final)
kmd.fit(data_final)
#np.savetxt('kmd.csv', kmd.centers_, delimiter=',')
# myscore = mode_cluster_score.score(data_final, kmd.centers_, kmd.labels_, 4, 1)
#print(myscore)
print('*********************')
print(kmd.centers_)
print(kmd.labels_)
plot_scatter(data_final, labels=kmd.labels_, title="k-medoids")
'''
    各簇中心（即各模型）绘图、fpc绘图
'''
