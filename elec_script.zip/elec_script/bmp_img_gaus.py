import numpy as np
from PIL import Image
import matplotlib.pyplot as plt


'''
    从data_for_cluster读取数据
'''

alldata = np.loadtxt(open(".\data_for_cluster.csv", "rb"), delimiter=",", skiprows=0)

data_for_gaus = []
length0 = len(alldata[0])
for x in range(0, length0):
    data_for_gaus_inner = []
    for y in range(0, 23):
        data_for_gaus_inner.append(alldata[y][x])
    data_for_gaus.append(data_for_gaus_inner)

'''
    取一天数据绘制灰度图，测试高斯滤波
'''
# 设置所绘制图的大小，长10宽10
fig = plt.figure(figsize=(20, 20))
# 开始绘制了

plt.plot(    #横坐标不填默认为0,1,2，，，，
     #time,             # X轴的数据,如果自定义time为横坐标，会发生错乱
    data_for_gaus[0],  # Y轴的数据
    linestyle='-',  # 折线的类型
    linewidth=6,  # 折线的宽度
    color='r',  # 折线的颜色
    marker='*',  # 折线的形状
    markersize=6
)
Name = 'fig.jpg'
plt.savefig(Name, dpi=400)
plt.close()
consume = []
# 彩图转换为灰度图
infile = './fig.jpg'
outfile = './gaus.jpg'
im = Image.open(infile).convert('L')
out = im.resize((50, 50), Image.ANTIALIAS)
out.save(outfile)

import GaussianBlur



'''
    循环遍历，绘制灰度图
'''
